#!/usr/bin/env python3
"""One fixed original-PCM AED diagnostic. Cannot read a reference or prompt."""
import datetime, hashlib, json, resource, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PCM = Path('/workspace/experiments/next-accuracy-oct14/data/user-lyrics.f32')

def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()

def save(value):
    tmp = ROOT / 'result.local.json.tmp'
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(ROOT / 'result.local.json')

def main():
    freeze = json.loads((ROOT / 'freeze-manifest.json').read_text())
    for name, expected in freeze['code_sha256'].items():
        if sha(ROOT / name) != expected: raise ValueError('Frozen code changed: ' + name)
    protocol = json.loads((ROOT / 'protocol-frozen.json').read_text())
    if set(protocol['input']) != {'id', 'format', 'sample_rate', 'bytes', 'sha256', 'seconds'}: raise ValueError('Reference-bearing input fields rejected')
    if PCM.stat().st_size != protocol['input']['bytes'] or sha(PCM) != protocol['input']['sha256']: raise ValueError('Frozen PCM changed')
    provenance = json.loads((ROOT / 'asset-provenance.json').read_text())
    if provenance.get('verified') is not True or {x['path'] for x in provenance['files']} != {'encoder.int8.onnx','decoder.int8.onnx','tokens.txt'}:
        raise ValueError('Incomplete AED asset provenance')
    for item in provenance['files']:
        p = ROOT / 'model' / item['path']
        if p.stat().st_size != item['bytes'] or sha(p) != item['sha256_tofu']: raise ValueError('Local TOFU asset verification failed')
    import numpy as np
    import sherpa_onnx
    if sherpa_onnx.__version__ != '1.13.8': raise ValueError('Sherpa version differs from fixed protocol')
    runtime = {'sherpa_version': sherpa_onnx.__version__, 'python':sys.version, 'numpy':np.__version__, 'native_cpu_not_browser': True}
    for name in ['git_sha1', 'git_date', 'onnxruntime_version']:
        v = getattr(sherpa_onnx, name); runtime[name] = v() if callable(v) else v
    output = {'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'protocol_sha256':sha(ROOT/'protocol-frozen.json'),'runner_sha256':sha(__file__),
              'input':protocol['input'],'model_files':provenance['files'],'runtime':runtime,
              'settings':protocol['decoding'],'references_read':False,'media_uploaded':False}
    save(output)
    start = time.perf_counter()
    model = ROOT / 'model'
    recognizer = sherpa_onnx.OfflineRecognizer.from_fire_red_asr(
        encoder=str(model/'encoder.int8.onnx'), decoder=str(model/'decoder.int8.onnx'), tokens=str(model/'tokens.txt'),
        num_threads=2, provider='cpu', decoding_method='greedy_search', debug=False,
        rule_fsts='',rule_fars='',hr_dict_dir='',hr_rule_fsts='',hr_lexicon='')
    output['load_seconds'] = time.perf_counter() - start
    save(output)
    pcm = np.fromfile(PCM, dtype='<f4')
    if len(pcm) != protocol['input']['bytes']//4 or not np.isfinite(pcm).all(): raise ValueError('Invalid entire PCM')
    start = time.perf_counter()
    stream = recognizer.create_stream()
    stream.accept_waveform(16000, pcm)
    recognizer.decode_stream(stream)
    result = stream.result
    output.update(status='complete',text=result.text,tokens=list(result.tokens),timestamps=list(result.timestamps),
                  decode_seconds=time.perf_counter()-start,peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  output_semantics='Exact Sherpa engine-returned text; not claimed to be full raw decoder logits/tokens before engine processing.')
    output['text_sha256'] = hashlib.sha256(output['text'].encode()).hexdigest()
    save(output)
    print(json.dumps({k:output[k] for k in ['status','load_seconds','decode_seconds','peak_rss_kib','text_sha256']}),flush=True)
    return 0

if __name__ == '__main__': raise SystemExit(main())
