# FireRedASR2-AED INT8 single lyric diagnostic

This is one previously seen private development recording, not a held-out singer,
new song dataset, browser test, or claim that lyric transcription is fixed.
The proposed candidate is the complete attention encoder-decoder (AED) model.
The CTC-only conversion is not substituted.

## Frozen experiment

- Original 16 kHz float32le mono PCM, 21.696 seconds and 1,388,544 bytes.
- PCM SHA256: `8933b1e813ec67abeb6de3067625a2dfec13672fd7706181cd571d143617794b`.
- Native Sherpa-ONNX 1.13.8, CPU, two threads, greedy search, 80-dimensional features.
- Empty hotwords; no lyric prompt, text retrieval, VAD, separation, trimming,
  splitting, gain, tempo, padding, homophone rules, or post-generation repair.
- Exactly one fresh native process, with a 300-second timeout and Linux `wait4`
  child wall/CPU/peak-RSS recording. Root allocated the sole model resource slot.
- The independent scorer reads the private user reference only after inference
  exits. It preserves the existing strict Chinese CER and stable S/D/I alignment.

`protocol-frozen.json` and the inference/download scripts were fingerprinted in
`freeze-manifest.json` before downloading the model or starting inference. The
scorer and its portable, mechanically adjusted dependencies were independently
fingerprinted in `scoring-frozen.json` before reading the private reference.

## Official source and hash boundary

The official Sherpa documentation names the complete AED artifact:

https://k2-fsa.github.io/sherpa/onnx/FireRedAsr/pretrained.html

Its original public release URL is:

https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-fire-red-asr2-zh_en-int8-2026-02-26.tar.bz2

GitHub's unauthenticated release-metadata API returned HTTP 403 (public rate
limit). The independently published direct release-download URL returned 200.
Frozen HEAD metadata includes an archive length of 838,589,068 bytes, an ETag,
and a 2026-02-26 Last-Modified date. A mutable release filename/ETag is not an
immutable Git revision or cryptographic publisher signature.

No publisher-provided expected SHA256 was obtained. The archive and extracted
model SHA256 values are **TOFU measurements from the first HTTPS download**.
Length and archive extraction completeness are checked; the native runner
rechecks every model asset against those measured local fingerprints. This is
not described as verification against an official checksum. The downloader
copies only the three exact model/token files and never applies archive
ownership, symlinks, or executable installation scripts.

The author paper reports strong clean singing performance on Opencpop:
https://arxiv.org/html/2603.10420v1
Those original model figures do not establish this INT8 conversion's accuracy
on reverberant concert recordings, browser performance, or phone feasibility.

## Reproduction

The scripts currently retain the exact absolute paths of this experiment to
preserve execution fingerprints. To rerun elsewhere, explicitly adapt the input
and interpreter locations and freeze a new protocol/source manifest; do not
claim the original fingerprint is unchanged. Obtain the recording and private
reference independently and lawfully. They are intentionally absent here.

1. Run `download-assets.py` to obtain and measure the official AED release.
2. Independently authorize exclusive resources in `resource-lock-authorized.json`.
3. Run `execute-diagnostic.py` with the pinned native environment. No second
   inference attempt is launched automatically, including on failure.
4. After the native process exits, run `node score-diagnostic.mjs` with the private
   scorer-manifest path as the sole argument. The manifest must have a `cases`
   entry for `user-lyrics`, matching the frozen PCM hash and Chinese language.
5. Read `result.public.json` for numeric/hash-only results. Full engine-returned
   text remains solely in `result.local.json`, never in the public source ZIP.

No model weights, PCM, video, private reference, full transcript, private logs,
temporary signed redirect URL, request cookies, or response bodies accompany the
code-and-receipt package. Native results do not imply any deployed product change.
