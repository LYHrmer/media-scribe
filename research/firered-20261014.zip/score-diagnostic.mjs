#!/usr/bin/env node
// Only executed after the one native process exits. Never imports an ASR model.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { lexicalScore } from './vendor/score-next-accuracy.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const sha = b => createHash('sha256').update(b).digest('hex');
const read = async name => JSON.parse(await fs.readFile(path.join(root, name), 'utf8'));
const receipt = await read('execution-receipt.json');
assert(['complete', 'failed'].includes(receipt.status), 'Native execution must be terminal before any reference read');
const protocol = await read('protocol-frozen.json');
const assets = await read('asset-provenance.json');
const freeze = await read('freeze-manifest.json');
const report = { schema_version: 1, scope: 'One previously seen private lyric development diagnostic; no holdout or generalization claim.',
  model: 'FireRedASR2-AED INT8, not CTC-only', inference_attempts: 1,
  execution: receipt, input: protocol.input, decoding: protocol.decoding, preprocessing: protocol.preprocessing,
  model_source: assets.source, official_expected_sha256: null, hash_boundary: assets.hash_boundary,
  archive_sha256_tofu: assets.archive_sha256_tofu, files: assets.files, code_sha256: freeze.code_sha256,
  native_runtime_files_sha256: freeze.runtime_sha256,
  status: receipt.status, score: null, references_read_for_scoring: false,
  scoring: { normalization: 'Existing strict NFKC/lowercase/punctuation-whitespace stripping; no phonetic, digit, synonym, Traditional/Simplified, or grammar repair.',
    tie_order: 'diagonal, deletion, insertion', punctuation: 'not evaluated' } };
if (receipt.status === 'complete' && receipt.returncode === 0) {
  const resultBytes = await fs.readFile(path.join(root, 'result.local.json'));
  const result = JSON.parse(resultBytes);
  assert.equal(result.status, 'complete');
  assert.equal(result.protocol_sha256, receipt.protocol_sha256);
  assert.equal(result.input.sha256, protocol.input.sha256);
  assert.equal(result.references_read, false);
  assert.equal(result.media_uploaded, false);
  assert.equal(typeof result.text, 'string');
  // The reference file is absent from the inference protocol and native runner.
  const referencePath = process.argv[2];
  assert(referencePath, 'Provide the private post-inference scorer manifest');
  const referenceBytes = await fs.readFile(path.resolve(referencePath));
  const references = JSON.parse(referenceBytes);
  const matches = references.cases.filter(c => c.id === 'user-lyrics');
  assert.equal(matches.length, 1);
  const ref = matches[0];
  assert.equal(ref.pcm_sha256, protocol.input.sha256);
  assert.equal(ref.language, 'chinese');
  const score = lexicalScore(ref.reference, result.text, 'chinese');
  assert.equal(score.reference_tokens, 22, 'The frozen user reference denominator must stay 22');
  report.score = score;
  report.references_read_for_scoring = true;
  report.provenance = { result_sha256: sha(resultBytes), reference_manifest_sha256: sha(referenceBytes),
    reference_text_sha256: sha(ref.reference), actual_text_sha256: sha(result.text),
    scoring_script_sha256: sha(await fs.readFile(fileURLToPath(import.meta.url))),
    dependencies: JSON.parse(await fs.readFile(path.join(root, 'vendor/provenance.json'), 'utf8')) };
  report.runtime = result.runtime;
  report.load_seconds = result.load_seconds;
  report.decode_seconds = result.decode_seconds;
  report.timestamp_count = result.timestamps.length;
  report.engine_text_semantics = result.output_semantics;
}
// Numeric/hash-only receipt: no reference, transcript, tokens, or model bytes.
await fs.writeFile(path.join(root, 'result.public.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: report.status, score: report.score,
  returncode: receipt.returncode, wall_seconds: receipt.wall_seconds, peak_rss_kib: receipt.peak_rss_kib }));
