#!/usr/bin/env python3
"""Exactly one fresh native process, no retries or reference reads."""
import datetime, hashlib, json, os, signal, subprocess, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def events():
    return {k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
def save(r): (ROOT/'execution-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
def main():
    lock=json.loads((ROOT/'resource-lock-authorized.json').read_text())
    if lock.get('authorized') is not True: raise ValueError('No root resource authorization')
    frozen=json.loads((ROOT/'freeze-manifest.json').read_text())
    for name,expected in frozen['code_sha256'].items():
        if sha(ROOT/name)!=expected: raise ValueError('Frozen code changed: '+name)
    argv=['/workspace/experiments/next-accuracy-oct14/runtime/bin/python',str(ROOT/'run-firered-native.py')]
    receipt={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'argv':argv,'protocol_sha256':sha(ROOT/'protocol-frozen.json'),'code_sha256':frozen['code_sha256'],
             'references_read':False,'memory_events_before':events(),'attempts':1,'resource_lock':lock}
    save(receipt)
    environment=os.environ.copy();environment.update(OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
    start=time.monotonic();deadline=start+300;timed_out=False
    log=ROOT/'inference.log.local.txt'
    with log.open('wb') as f:
        process=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT,env=environment,start_new_session=True)
        while True:
            pid,status,usage=os.wait4(process.pid,os.WNOHANG)
            if pid: break
            if time.monotonic()>deadline and not timed_out:
                timed_out=True;os.killpg(process.pid,signal.SIGKILL)
            time.sleep(.2)
    code=os.waitstatus_to_exitcode(status)
    receipt.update(status='complete' if code==0 else 'failed',returncode=code,timed_out=timed_out,
                   wall_seconds=time.monotonic()-start,peak_rss_kib=usage.ru_maxrss,
                   cpu_user_seconds=usage.ru_utime,cpu_system_seconds=usage.ru_stime,
                   memory_events_after=events(),private_log_sha256=sha(log),
                   finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),resource_source='Linux wait4 child rusage')
    save(receipt)
    print(json.dumps({k:receipt[k] for k in ['status','returncode','wall_seconds','peak_rss_kib','timed_out']}),flush=True)
    return code if code>=0 else 1
if __name__=='__main__':raise SystemExit(main())
