#!/usr/bin/env python3
"""Fixed official AED release only. No model inference or media/reference access."""
import datetime, hashlib, json, tarfile, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROTOCOL = json.loads((ROOT / 'protocol-frozen.json').read_text())
SOURCE = PROTOCOL['model_source']

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def main():
    archive = ROOT / SOURCE['archive_name']
    partial = archive.with_suffix(archive.suffix + '.partial')
    download = {'source': SOURCE, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'author_expected_sha256': None, 'hash_boundary': 'TOFU: SHA256 measured after the first HTTPS release download, not a publisher-provided checksum.',
                'attempts': [], 'verified': False, 'files': []}
    save(ROOT / 'asset-provenance.json', download)
    if not archive.exists():
        for attempt in range(3):
            try:
                offset = partial.stat().st_size if partial.exists() else 0
                headers = {'User-Agent': 'tingxie-frozen-firered-diagnostic'}
                if offset: headers.update(Range=f'bytes={offset}-', **{'If-Range': SOURCE['etag']})
                request = urllib.request.Request(SOURCE['url'], headers=headers)
                with urllib.request.urlopen(request, timeout=90) as response:
                    append = offset > 0 and response.status == 206
                    if append and not response.headers.get('Content-Range', '').startswith(f'bytes {offset}-'):
                        raise ValueError('Unexpected resume Content-Range')
                    if response.headers.get('ETag') != SOURCE['etag']:
                        raise ValueError('Official release ETag changed after protocol freeze')
                    download['attempts'].append({'attempt': attempt + 1, 'status': response.status,
                                                'resumed_bytes': offset if append else 0,
                                                'etag': response.headers.get('ETag'),
                                                'last_modified': response.headers.get('Last-Modified')})
                    save(ROOT / 'asset-provenance.json', download)
                    with partial.open('ab' if append else 'wb') as out:
                        last = time.monotonic()
                        while block := response.read(1024 * 1024):
                            out.write(block)
                            if out.tell() > SOURCE['bytes']: raise ValueError('Release exceeds frozen length')
                            if time.monotonic() - last > 5:
                                print(json.dumps({'download_bytes': out.tell(), 'total_bytes': SOURCE['bytes']}), flush=True)
                                last = time.monotonic()
                if partial.stat().st_size != SOURCE['bytes']: raise ValueError('Incomplete archive')
                partial.replace(archive)
                break
            except Exception as error:
                download['attempts'].append({'attempt': attempt + 1, 'error': str(error)})
                save(ROOT / 'asset-provenance.json', download)
                print(json.dumps({'download_error': str(error), 'attempt': attempt + 1}), flush=True)
                if attempt == 2: raise
                time.sleep(1)
    if archive.stat().st_size != SOURCE['bytes']: raise ValueError('Archive length differs from frozen official HEAD')
    download['archive_sha256_tofu'] = sha(archive)
    model_root = ROOT / 'model'
    model_root.mkdir(exist_ok=True)
    prefix = 'sherpa-onnx-fire-red-asr2-zh_en-int8-2026-02-26/'
    expected = {'encoder.int8.onnx', 'decoder.int8.onnx', 'tokens.txt'}
    found = set()
    with tarfile.open(archive, 'r|bz2') as tar:
        for member in tar:
            if member.name not in {prefix + n for n in expected}: continue
            name = member.name[len(prefix):]
            if name in found or not member.isfile(): raise ValueError('Unsafe or duplicate model member')
            if member.size > 1200 * 1024 * 1024 or member.size <= 0: raise ValueError('Unexpected member size')
            target = model_root / name
            source = tar.extractfile(member)
            with target.open('wb') as out:
                while block := source.read(1024 * 1024): out.write(block)
            if target.stat().st_size != member.size: raise ValueError('Truncated extracted member')
            found.add(name)
            row = {'path': name, 'bytes': member.size, 'sha256_tofu': sha(target)}
            download['files'].append(row)
            save(ROOT / 'asset-provenance.json', download)
            print(json.dumps({'extracted': row}), flush=True)
    if found != expected: raise ValueError('Required AED assets missing')
    download.update(verified=True, integrity_check='All archive/member lengths checked; every file pinned to measured local TOFU SHA for future rechecks.',
                    total_model_bytes=sum(x['bytes'] for x in download['files']),
                    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save(ROOT / 'asset-provenance.json', download)
    print(json.dumps({'download_complete': True, 'total_model_bytes': download['total_model_bytes'], 'archive_sha256_tofu': download['archive_sha256_tofu']}), flush=True)

if __name__ == '__main__': main()
