# 字幕裁片与绿通道：固定四臂研究源码

这是未进入产品的 OCR 对照代码。四臂各跑相同 43 个时刻，共 172 次真实帧推理。使用 PP-OCRv4 mobile（standard），只交叉改变 DB 扩框比（1.6 / 1.0）和识别裁片颜色（原色 / 绿通道）。没有微调、词表修正、答案提示、逐帧选最佳结果或自动覆盖语音正文。

可读子集错误依次是 6/72、6/72、5/72、4/72；最佳子集的 B1 丢掉两处原来有输出的字幕区域，保留框覆盖从 16/44 降至 14/44，未通过采用门槛。**72 字只是一条 8 字字幕的 9 帧重复读数；困难后段没有完整参考，完整歌词 CER 为 null。** 参考由独立 Astra 代理从空白上下文只看像素标注，没有看到歌词答案或 OCR 输出；它不是用户/人工逐帧金标准，未人工复核。没有新真实视频泛化或手机浏览器稳定性验证。

## 包含与不包含

- `experiment-spec.json`：原冻结协议的无本机路径投影，保留原协议 SHA、43 帧哈希、全部四臂和模型/runtime/Worker 指纹。
- `worker/src/`、`patches/ocr-diagnostics.patch`：隔离的实验源码与相对生产基线的诊断改动。正常保留阈值仍为 0.5；另记录所有后处理框的 CTC 字符、分数、几何、方向、裁片哈希和拒绝原因。
- `scripts/`：抽帧、构建、预检、串行运行、离线评分及 8 个合成回归测试。真实运行器 `test-ocr-wasm.mjs` 与当时仓库文件逐字一致。
- `scoring-method-frozen.json`、`scoring-audit-amendment.json`：评分规则与随后只增完整性校验的记录；匹配实现是在推理开始后、任何候选与参考文字正确性比较之前冻结。
- `caption-results-public.json`：全部四臂的计数与哈希，不含私人文字；`SOURCE_PROVENANCE.json`、`SHA256SUMS` 记录来源与归档文件指纹。

不含媒体、PNG、RGBA、参考全文、OCR 全文、模型、依赖安装目录、编译 Worker 或 WASM。因私人材料不公开，公众无法仅凭这个包复算报告数字；可以检查算法、协议、哈希和聚合结论，并用自己另行冻结的材料开展新实验。不要把更换媒体、权重或参数后的结果当作本报告复现。

## 本机复放

需要 Node.js ≥20、Python 3、ffmpeg；抽帧额外使用 Pillow。安装主项目锁定依赖，模型及 ONNX runtime 使用主项目已验证的本地文件。此包不自动下载模型，也不接触外部 ASR。固定依赖为 OpenCV 4.9.0-release.3、js-clipper 1.0.1、onnxruntime-web 1.22.0-dev.20250409-89f8206ba4、Vite 6.3.5；模型 SHA 见协议。第三方代码/权重许可沿用主项目说明，模型不在归档中。

在解压后的源码包根目录操作。`TINGXIE_PROJECT_ROOT` 指向已经安装上述锁定依赖、准备好 `public/models-ocr` 与 `public/vendor/ort` 的主项目检出目录。

```bash
export TINGXIE_PROJECT_ROOT=/absolute/path/to/tingxie-web
node scripts/build-worker.mjs
node --test scripts/score-visual.test.mjs
```

持有原始私有视频的授权者可在本机重建帧；脚本应用 ffmpeg 默认旋转，按 0.25 + 0.5×index 秒采样，不依照文字选帧。视频结束前最后一个计划时刻无法解码，原实验保留 43 个不同采样时刻。不同 ffmpeg/Pillow 版本可能导致像素或 PNG 哈希差异，预检会停止，不默默接受漂移。

```bash
python scripts/prepare-frames.py /absolute/path/to/private-video.mp4 /absolute/path/to/private-frames
python scripts/prepare-run.py \
  --project "$TINGXIE_PROJECT_ROOT" \
  --frames-dir /absolute/path/to/private-frames \
  --output /absolute/path/to/new-private-run
```

`prepare-run.py` 只绑定本机路径，核对全部 43 帧、模型、runner、编译 Worker 与 WASM 哈希，生成新的本机协议和四份无参考推理清单。新协议的哈希随路径变化，保留原冻结协议的来源哈希。它不加载模型，不读参考，不覆盖旧运行目录。新编译 Worker 不同则停止；请先排查依赖/构建漂移，不能绕过校验后仍称固定复现。

```bash
python scripts/run-frozen-ocr.py \
  --protocol /absolute/path/to/new-private-run/protocol.local.json \
  --protocol-sha ACTUAL_SHA256_FROM_PREPARE_RUN

# 在机器资源空闲时显式执行；四臂串行，共约 17 分钟（本次实测）
python scripts/run-frozen-ocr.py --execute --arm all \
  --protocol /absolute/path/to/new-private-run/protocol.local.json \
  --protocol-sha ACTUAL_SHA256_FROM_PREPARE_RUN
```

默认只预检，`--execute` 才推理；拒绝覆盖输出，保留每臂退出码和日志。进程执行的是编译 Worker 中真实 OpenCV/ONNX WASM，本地模拟 HTTPS 模型读取和 Cache API，不是浏览器视频解码、页面交互或手机内存测试。全部模型和帧在本机读取；推理清单没有任何参考/歌词字段。

## 参考冻结与离线评分

先由不看任何输出/答案的独立标注者逐帧冻结参考文件及 SHA，之后才评分。参考 schema 是 `frames` 数组，每帧含 `frame_index`、`time_seconds`、`image_path`、`image_sha256`、`width`、`height`、`status`、`regions`。区域含 `region_id`、`bbox_xyxy`、`orientation`、`status`、`text`、`readable_spans`、`issues`、`score_text`。原图像素坐标需有效；全可读才设置 `score_text: true`。局部不清的连续区可标 `[unclear]`，它不代表确定字数；仅确信的连续片段放进 `readable_spans`，不得补入语音答案。

```bash
node scripts/score-visual.mjs \
  --protocol /absolute/path/to/new-private-run/protocol.local.json \
  --protocol-sha ACTUAL_SHA256_FROM_PREPARE_RUN \
  --reference /absolute/path/to/private-reference.json \
  --reference-sha FROZEN_REFERENCE_SHA256 \
  --output /absolute/path/to/new-private-run/visual-scored.json
```

主匹配只按最大 IoU≥0.10，每预测分配一次，另完整输出固定 IoU≥0.25 的敏感性结果；本次二者一致。全部已匹配文字按空间顺序保留，不按照参考或置信度择优。只有全可读框算 CER；局部框统计已知片段按序保留，不能当完整字错误率。输出在框外不等于拼写错误，需要另外像素核实。正常退出且帧齐全才有完整臂指标；输出、协议、Worker、WASM、参数与实际退出收据逐项绑定。不向 OCR 传入参考，不调用模型做评分。

`scoreArm`、几何与绑定函数与实验最终评分器逐字一致；移植版只把绝对 import/路径改为相对路径和显式 CLI 参数。8 个合成测试检查漏字、文字泄漏匹配、局部参考滥用、失败退出、零分母、图像身份、非法框、收据/参数替换。测试通过不能代表真实字幕准确率。归档移植后的评分器另用本机已有结果重放核对，未重跑 OCR。

## 可继续研究的缺口

四臂都只有 20/44 个字幕区域被原始框覆盖；更小扩框没有解决主要漏检。B1 降低两处可读子集替换，但后段一个原保留片段丢失，空 CTC 从 A0 的 30 增至 42。远处小字、模糊/高亮穿字、出画和移动取景需要各自证据；不可用语言通顺度证明恢复。增强 server 权重未在此协议运行，不应将此结果标成 enhanced。后续新方法要另冻协议和未见材料，保留失败臂与全部指标。
