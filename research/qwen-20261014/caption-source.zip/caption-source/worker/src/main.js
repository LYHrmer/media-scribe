globalThis.ocrDiagnosticWorker = new Worker(new URL('./video-ocr.worker.js', import.meta.url), { type: 'module' });
