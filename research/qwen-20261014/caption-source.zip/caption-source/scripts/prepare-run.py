"""Bind the public, path-free fixed protocol to local files. No inference/download/reference."""
from pathlib import Path
import argparse, copy, datetime, hashlib, json

ROOT = Path(__file__).resolve().parent.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('--project', type=Path, required=True)
parser.add_argument('--frames-dir', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
a = parser.parse_args()
project, frames_dir, output = a.project.resolve(), a.frames_dir.resolve(), a.output.resolve()
spec_path = ROOT / 'experiment-spec.json'
spec = json.loads(spec_path.read_text())
assert spec['original_protocol_sha256'] == '3f02b9a10631a4cd90874369d68a4a6bdd619a03bd768df86f365372b317af8e'
assert len(spec['frames']) == 43
assert [(x['id'], x['unclipRatio'], x['colorMode']) for x in spec['arms']] == [
    ('A0', 1.6, 'original'), ('A1', 1.6, 'green'), ('B0', 1.0, 'original'), ('B1', 1.0, 'green')]
runner = ROOT / spec['runner']['archive_path']
assert sha(runner) == spec['runner']['sha256'], 'Runner drift'
workers = list((ROOT / 'worker/dist/assets').glob('video-ocr.worker-*.js'))
assert len(workers) == 1, 'Build isolated Worker first'
worker = workers[0]
assert sha(worker) == spec['worker']['sha256'], 'Built Worker differs; investigate, do not label it the fixed experiment'
runtime = project / 'public/vendor/ort'
assert sha(runtime / spec['runtime']['filename']) == spec['runtime']['sha256'], 'WASM drift'
assets = []
for x in spec['assets']:
    p = project / 'public/models-ocr' / x['name']
    assert p.stat().st_size == x['bytes'] and sha(p) == x['sha256'], x['name']
    assets.append({'path': str(p), 'bytes': x['bytes'], 'sha256': x['sha256']})
frames = []
for x in spec['frames']:
    png, rgba = frames_dir / x['png_name'], frames_dir / x['rgba_name']
    assert sha(png) == x['png_sha256'] and sha(rgba) == x['rgba_sha256'], x['id']
    assert rgba.stat().st_size == x['width'] * x['height'] * 4
    frames.append({k: v for k, v in x.items() if k not in ['png_name', 'rgba_name']} |
                  {'png_path': str(png), 'rgba_path': str(rgba)})
output.mkdir(parents=True, exist_ok=False)
(output / 'manifests').mkdir()
(output / 'results').mkdir()
arms = []
for x in spec['arms']:
    manifest = [{'name': f't={f["time"]:.3f}', 'time': f['time'], 'rgba': f['rgba_path'],
                 'width': f['width'], 'height': f['height'],
                 'options': {'maxSide': 1920, 'maxLines': 32, 'recognitionThreshold': .5,
                             'boxThreshold': .5, 'colorMode': x['colorMode'],
                             'unclipRatio': x['unclipRatio'], 'diagnostics': True}} for f in frames]
    m = output / 'manifests' / f'{x["id"]}.local.json'
    m.write_text(json.dumps(manifest, indent=2) + '\n')
    arms.append({k: v for k, v in x.items() if k != 'manifest_sha256'} |
                {'manifest_path': str(m), 'manifest_sha256': sha(m),
                 'output_path': str(output / 'results' / f'{x["id"]}.json'),
                 'log_path': str(output / 'results' / f'{x["id"]}.log')})
protocol = {k: copy.deepcopy(v) for k, v in spec.items()
            if k not in ['frames', 'arms', 'runner', 'worker', 'runtime', 'assets', 'archive_format']}
protocol.update(status='path-adapted replay of the original frozen experiment',
                prepared_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                public_spec_sha256=sha(spec_path), frames=frames, arms=arms,
                runner={'path': str(runner), 'sha256': sha(runner)},
                worker={'path': str(worker), 'sha256': sha(worker)},
                runtime={'directory': str(runtime), 'wasm_sha256': spec['runtime']['sha256']},
                assets=assets)
p = output / 'protocol.local.json'
p.write_text(json.dumps(protocol, ensure_ascii=False, indent=2) + '\n')
(output / 'protocol.sha256').write_text(sha(p) + '\n')
print(json.dumps({'status': 'prepared_no_inference', 'protocol': str(p), 'sha256': sha(p),
                  'reference_read': False, 'model_loaded': False}))
