"""Run the predeclared four-arm experiment serially. Never reads references."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,fcntl,time
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--arm',choices=['all','A0','A1','B0','B1'],default='all');parser.add_argument('--protocol',type=Path,required=True);parser.add_argument('--protocol-sha',required=True);a=parser.parse_args();ROOT=a.protocol.resolve().parent;EXPECTED_PROTOCOL_SHA=a.protocol_sha
p=a.protocol.resolve();assert sha(p)==EXPECTED_PROTOCOL_SHA
x=json.loads(p.read_text());selected=[v for v in x['arms'] if a.arm=='all' or v['id']==a.arm]
for spec in [x['runner'],x['worker'],*x['assets']]:assert sha(spec['path'])==spec['sha256'],spec['path']
assert sha(Path(x['runtime']['directory'])/'ort-wasm-simd-threaded.wasm')==x['runtime']['wasm_sha256']
for f in x['frames']:assert sha(f['rgba_path'])==f['rgba_sha256'],f['id']
for v in selected:assert sha(v['manifest_path'])==v['manifest_sha256']
if not a.execute:
 print(json.dumps({'status':'preflight_pass','arms':[v['id'] for v in selected],'model_loaded':False}));raise SystemExit(0)
with (ROOT/'results/run.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for v in selected:
  output=Path(v['output_path']);log=Path(v['log_path']);receipt=ROOT/'results'/f'{v["id"]}-execution.json'
  assert not output.exists() and not log.exists() and not receipt.exists(),'Never overwrite a previous run'
  cmd=['node','--experimental-vm-modules',x['runner']['path'],'--worker',x['worker']['path'],'--assets',str(Path(x['assets'][0]['path']).parent),'--runtime',x['runtime']['directory'],'--frames',v['manifest_path'],'--precision',v['precision'],'--output',str(output)]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
  state={'arm':v['id'],'status':'running','started_utc':started,'command':cmd,'protocol_sha256':EXPECTED_PROTOCOL_SHA,'reference_file_read':False}
  receipt.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({'arm':v['id'],'status':'starting','started_utc':started}),flush=True)
  with log.open('x') as stream: proc=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
  state.update(status='complete' if proc.returncode==0 else 'failed',observed_exit_code=proc.returncode,elapsed_seconds=time.monotonic()-t,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=sha(log))
  if output.exists():
   state['output_sha256']=sha(output);r=json.loads(output.read_text());state['completed_frames']=len(r.get('results',[]))
   expected={f't={f["time"]:.3f}':f['rgba_sha256'] for f in x['frames']}
   assert all(z['pixelSha256']==expected[z['name']] for z in r['results'])
   state['raw_observations']=sum(len(z['result']['experimental']['rawObservations']) for z in r['results'])
   state['accepted_observations']=sum(len(z['result']['texts']) for z in r['results'])
   if proc.returncode==0: assert state['completed_frames']==43
  receipt.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:state[k] for k in ['arm','status','observed_exit_code','elapsed_seconds','completed_frames','raw_observations','accepted_observations'] if k in state}),flush=True)
