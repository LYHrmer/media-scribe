import test from 'node:test';import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {scoreArm,assignGeometry,validateExecutionBinding} from './score-visual.mjs';
const box=(x,y,w,h)=>[[x,y],[x+w,y],[x+w,y+h],[x,y+h]];
const protocol={frames:[{time:.25,png_sha256:'png',rgba_sha256:'rgba',width:100,height:100}]};
const reference=regions=>({frames:[{frame_index:0,time_seconds:.25,image_sha256:'png',width:100,height:100,regions}]});
const region=(id,bbox,text,score_text=true)=>({region_id:id,bbox_xyxy:bbox,orientation:'horizontal',status:score_text?'readable':'partially_readable',text,score_text,readable_spans:score_text?[]:['丙']});
const result=texts=>({results:[{name:'t=0.250',pixelSha256:'rgba',result:{texts,experimental:{rawObservations:texts}}}]});
const execution={status:'complete',observed_exit_code:0};
test('Missing caption is deletion, unmatched fluent text cannot repair it',()=>{
 const ref=reference([region('r',[0,0,20,10],'甲乙')]);const r=scoreArm(protocol,ref,result([{text:'甲乙',box:box(70,70,20,10)}]),execution);
 assert.equal(r.summary.deletions,2);assert.equal(r.summary.full_readable_subset_CER,1);assert.equal(r.summary.accepted_observations_outside_caption_regions,1);
});
test('Uncertain spans are not converted into complete-line truth',()=>{
 const ref=reference([region('a',[0,0,20,10],'甲乙'),region('b',[0,30,20,40],'丙[unclear]',false)]);
 const r=scoreArm(protocol,ref,result([{text:'甲乙',box:box(0,0,20,10)},{text:'丙丁戊',box:box(0,30,20,10)}]),execution);
 assert.equal(r.summary.full_readable_subset_reference_characters,2);assert.equal(r.summary.full_readable_subset_CER,0);
 assert.equal(r.summary.partial_known_spans_exact_in_order,1);assert.equal(r.summary.accepted_output_characters_in_unscorable_regions,3);assert.equal(r.summary.full_video_CER,null);
});
test('Nonzero exit never produces a full-arm score even with complete rows',()=>{
 const r=scoreArm(protocol,reference([region('r',[0,0,20,10],'甲乙')]),result([{text:'甲乙',box:box(0,0,20,10)}]),{status:'complete',observed_exit_code:1});
 assert.equal(r.summary.full_readable_subset_CER,null);assert.equal(r.summary.execution_complete,false);
});
test('No-caption output counted separately, never zero-denominator CER=0',()=>{
 const r=scoreArm(protocol,reference([]),result([{text:'甲',box:box(0,0,10,10)}]),execution);
 assert.equal(r.summary.frames_with_no_caption_region_but_accepted_output,1);assert.equal(r.summary.full_readable_subset_CER,null);
});
test('Prediction matches one geometric region, not the reference spelling',()=>{
 const a=assignGeometry([{text:'乙',box:box(0,0,20,10)}],[region('a',[0,0,20,10],'甲'),region('b',[70,70,90,80],'乙')],.1);
 assert.equal(a.groups[0].length,1);assert.equal(a.groups[1].length,0);
});
test('Wrong source image cannot be scored',()=>{
 const ref=reference([]);ref.frames[0].image_sha256='different';assert.throws(()=>scoreArm(protocol,ref,result([]),execution));
});

test('Inverted reference boxes fail instead of silently losing recall',()=>{
 assert.throws(()=>scoreArm(protocol,reference([region('bad',[0,30,20,10],'甲')]),result([]),execution),/Invalid reference geometry/);
});

test('Swapped outputs, arm names, or loaded parameters fail provenance checks',()=>{
 const bytes=Buffer.from('fixed-output'),digest=createHash('sha256').update(bytes).digest('hex');
 const p={worker:{sha256:'worker'},runtime:{wasm_sha256:'wasm'}},arm={id:'A0',colorMode:'original',unclipRatio:1.6};
 const result={worker:{sha256:'worker'},wasm:{sha256:'wasm'},results:[{result:{colorMode:'original',experimental:{unclipRatio:1.6,recognitionThreshold:.5,boxThreshold:.5}}}]};
 const receipt={arm:'A0',protocol_sha256:'protocol',output_sha256:digest};
 validateExecutionBinding(p,arm,'protocol',bytes,result,receipt);
 assert.throws(()=>validateExecutionBinding(p,arm,'protocol',Buffer.from('other'),result,receipt),/Receipt output mismatch/);
 assert.throws(()=>validateExecutionBinding(p,{...arm,id:'A1'},'protocol',bytes,result,receipt),/different arm/);
 assert.throws(()=>validateExecutionBinding(p,{...arm,colorMode:'green'},'protocol',bytes,result,receipt),/Wrong colour arm/);
});
