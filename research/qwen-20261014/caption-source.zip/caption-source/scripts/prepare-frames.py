"""Private development-video decoding. No reference answer or text prompt."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from PIL import Image

parser = argparse.ArgumentParser()
parser.add_argument('video', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
metadata = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(args.video)]))
duration = float(metadata['format']['duration'])
manifest = []
unavailable = []
index = 0
while (time := 0.25 + index * 0.5) < duration:
    png = args.output / f'frame-{index:03d}.png'
    rgba = args.output / f'frame-{index:03d}.rgba'
    if not png.exists():
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-ss', str(time), '-i', str(args.video), '-frames:v', '1', '-threads', '1', '-y', str(png)], check=True)
    if not png.exists():
        unavailable.append(time)
        index += 1
        continue
    image = Image.open(png).convert('RGBA')
    rgba.write_bytes(image.tobytes())
    manifest.append({'name': f't={time:.3f}', 'time': time, 'rgba': rgba.name,
        'png': png.name, 'width': image.width, 'height': image.height, 'options': {'maxSide': 1920}})
    index += 1
(args.output / 'frames.local.json').write_text(json.dumps(manifest, indent=2) + '\n')
(args.output / 'provenance.local.json').write_text(json.dumps({
    'source': str(args.video), 'sha256': hashlib.sha256(args.video.read_bytes()).hexdigest(),
    'durationSeconds': duration, 'sampling': '0.25 + 0.5 * index seconds, fixed schedule before OCR',
    'frameCount': len(manifest), 'unavailableNearEndTimes': unavailable, 'referenceUsed': False,
    'scope': 'Existing private development video; not a new independent accuracy holdout.',
    'decoder': subprocess.check_output(['ffmpeg', '-version'], text=True).splitlines()[0],
}, indent=2) + '\n')
print(json.dumps({'frames': len(manifest), 'duration': duration, 'output': str(args.output)}))
