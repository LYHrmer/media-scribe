// Builds isolated source only; never loads models or video.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.resolve(fileURLToPath(new URL('../',import.meta.url)));
if(!process.env.TINGXIE_PROJECT_ROOT)throw new Error('Set TINGXIE_PROJECT_ROOT to the installed source checkout');
const project=path.resolve(process.env.TINGXIE_PROJECT_ROOT),worker=path.join(root,'worker');
const modules=path.join(worker,'node_modules'),target=path.join(project,'node_modules');
try { const stat=await fs.lstat(modules); if(!stat.isSymbolicLink() || await fs.realpath(modules)!==await fs.realpath(target))throw new Error('Worker node_modules must link to selected checkout'); }
catch(e) { if(e.code!=='ENOENT')throw e;await fs.symlink(target,modules,'dir'); }
const {build}=await import(pathToFileURL(path.join(target,'vite/dist/node/index.js')).href);
await build({root:worker,base:'/',publicDir:false,worker:{format:'es'},build:{outDir:'dist',emptyOutDir:true}});
