// Offline only. Pixel/reference truth is never passed to the OCR runner.
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { lexicalScore, charTokens } from '../research/qwen-20261014/scripts/score-next-accuracy.mjs';
const sha = value => createHash('sha256').update(value).digest('hex');
export function validateExecutionBinding(protocol,arm,protocolSha,resultBytes,result,execution) {
  assert.equal(execution.arm,arm.id,'Receipt belongs to a different arm');
  assert.equal(execution.protocol_sha256,protocolSha,'Receipt protocol mismatch');
  assert.equal(execution.output_sha256,sha(resultBytes),'Receipt output mismatch');
  assert.equal(result.worker.sha256,protocol.worker.sha256,'Worker mismatch');
  assert.equal(result.wasm.sha256,protocol.runtime.wasm_sha256,'WASM mismatch');
  for(const row of result.results) {
    assert.equal(row.result.colorMode,arm.colorMode,'Wrong colour arm');
    assert.equal(row.result.experimental.unclipRatio,arm.unclipRatio,'Wrong crop arm');
    assert.equal(row.result.experimental.recognitionThreshold,.5);
    assert.equal(row.result.experimental.boxThreshold,.5);
  }
}
export function bounds(observation) {
  assert(Array.isArray(observation.box) && observation.box.length === 4);
  return [Math.min(...observation.box.map(p=>p[0])),Math.min(...observation.box.map(p=>p[1])),Math.max(...observation.box.map(p=>p[0])),Math.max(...observation.box.map(p=>p[1]))];
}
export function iou(a,b) {
  const intersection=Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]));
  const area=q=>Math.max(0,q[2]-q[0])*Math.max(0,q[3]-q[1]);
  const union=area(a)+area(b)-intersection;return union ? intersection/union : 0;
}
export function assignGeometry(observations,regions,threshold) {
  const groups=regions.map(()=>[]),unmatched=[];
  for(const observation of observations) {
    const bbox=bounds(observation);let best=-1,value=threshold;
    for(let j=0;j<regions.length;j++) {
      const candidate=iou(bbox,regions[j].bbox_xyxy);
      if(candidate>=threshold && (best<0 || candidate>value)) {best=j;value=candidate;}
    }
    if(best<0) unmatched.push(observation);else groups[best].push(observation);
  }
  return {groups,unmatched};
}
export function readingOrder(observations,orientation) {
  return [...observations].sort((a,b)=>{
    const x=bounds(a),y=bounds(b);return orientation==='vertical' ? x[1]-y[1] || x[0]-y[0] : x[0]-y[0] || x[1]-y[1];
  }).map(x=>x.text).join(' ');
}
export function scoreArm(protocol,reference,result,execution,threshold=.1) {
  assert.equal(reference.frames.length,protocol.frames.length);
  const byName=new Map((result?.results??[]).map(x=>[x.name,x]));assert.equal(byName.size,result?.results?.length??0);
  const expectedNames=new Set(protocol.frames.map(f=>`t=${f.time.toFixed(3)}`));
  for(const name of byName.keys())assert(expectedNames.has(name),'Unexpected frame in result');
  const complete=execution?.status==='complete' && execution.observed_exit_code===0 && byName.size===protocol.frames.length;
  const regions=[],frames=[];
  let unmatchedRegions=0,unmatchedCharacters=0,unscoredCharacters=0;
  let noCaptionFrameOutputs=0,rawRegions=0,acceptedRegions=0,partialSpanCount=0,partialSpansPreserved=0;
  for(let i=0;i<protocol.frames.length;i++) {
    const source=protocol.frames[i],ref=reference.frames[i];assert.equal(ref.frame_index,i);assert.equal(ref.time_seconds,source.time);
    assert.equal(ref.image_sha256,source.png_sha256);assert.equal(ref.width,source.width);assert.equal(ref.height,source.height);
    for(const region of ref.regions) {
      const b=region.bbox_xyxy;
      assert(Array.isArray(b) && b.length===4 && b.every(Number.isFinite));
      assert(b[0]>=0 && b[1]>=0 && b[2]<=source.width && b[3]<=source.height && b[2]>b[0] && b[3]>b[1],'Invalid reference geometry');
    }
    const row=byName.get(`t=${source.time.toFixed(3)}`);
    if(row)assert.equal(row.pixelSha256,source.rgba_sha256);
    const accepted=row?.result?.texts??[],raw=row?.result?.experimental?.rawObservations??[];
    const mapped=assignGeometry(accepted,ref.regions,threshold),rawMapped=assignGeometry(raw,ref.regions,threshold);
    unmatchedRegions+=mapped.unmatched.length;unmatchedCharacters+=mapped.unmatched.reduce((n,o)=>n+charTokens(o.text).length,0);
    if(ref.regions.length===0 && accepted.length)noCaptionFrameOutputs++;
    for(let j=0;j<ref.regions.length;j++) {
      const region=ref.regions[j],hyp=readingOrder(mapped.groups[j],region.orientation);
      const hasRaw=rawMapped.groups[j].length>0,hasAccepted=mapped.groups[j].length>0;
      rawRegions+=Number(hasRaw);acceptedRegions+=Number(hasAccepted);
      const item={frame_index:i,time_seconds:source.time,region_id:region.region_id,status:region.status,score_text:region.score_text,
        raw_region_detected:hasRaw,accepted_region_detected:hasAccepted,accepted_observations:mapped.groups[j].length,
        hypothesis_characters:charTokens(hyp).length,hypothesis_sha256:sha(hyp),score:null};
      if(region.score_text) {
        assert.equal(typeof region.text,'string');assert(!region.text.includes('[unclear]'));
        item.reference_sha256=sha(region.text);item.score=row?lexicalScore(region.text,hyp,'chinese'):null;
      } else {
        unscoredCharacters+=charTokens(hyp).length;
        if(region.status==='partially_readable') {
          const normalized=charTokens(hyp).join('');let cursor=0;
          item.known_spans=[];
          for(const span of region.readable_spans) {
            assert.equal(typeof span,'string');assert(!span.includes('[unclear]'));
            const needle=charTokens(span).join('');assert(needle.length>0);
            const at=normalized.indexOf(needle,cursor),present=at>=0;if(present)cursor=at+needle.length;
            partialSpanCount++;partialSpansPreserved+=Number(present);
            item.known_spans.push({reference_sha256:sha(span),reference_characters:charTokens(span).length,exact_in_order:present});
          }
        }
      }
      regions.push(item);
    }
    frames.push({frame_index:i,time_seconds:source.time,status:row?'complete':'missing',annotated_regions:ref.regions.length,
      accepted_observations:accepted.length,raw_observations:raw.length,accepted_outside_annotated_caption_regions:mapped.unmatched.length});
  }
  const full=regions.filter(r=>r.score_text),scored=full.filter(r=>r.score);
  const total=key=>scored.reduce((n,r)=>n+r.score[key],0);
  const errors=total('errors'),denominator=total('reference_tokens');
  const summary={execution_complete:complete,expected_frames:protocol.frames.length,completed_frames:byName.size,
    expected_caption_regions:regions.length,fully_readable_reference_regions:full.length,scored_reference_regions:scored.length,
    full_readable_subset_CER:complete && scored.length===full.length && denominator?errors/denominator:null,
    full_readable_subset_errors:complete?errors:null,full_readable_subset_reference_characters:complete?denominator:null,
    substitutions:complete?total('substitutions'):null,deletions:complete?total('deletions'):null,insertions:complete?total('insertions'):null,
    exact_full_readable_regions:complete?scored.filter(r=>r.score.errors===0).length:null,
    raw_caption_region_coverage:rawRegions,accepted_caption_region_coverage:acceptedRegions,
    partial_known_spans:partialSpanCount,partial_known_spans_exact_in_order:complete?partialSpansPreserved:null,
    accepted_output_characters_in_unscorable_regions:unscoredCharacters,
    accepted_observations_outside_caption_regions:unmatchedRegions,accepted_characters_outside_caption_regions:unmatchedCharacters,
    frames_with_no_caption_region_but_accepted_output:noCaptionFrameOutputs,
    individual_scores_scope:complete?'Completed arm, restricted independently readable subset':'Incomplete-run diagnostics only; not a full-arm accuracy result',
    full_video_CER:null,full_video_CER_reason:'Partial and unreadable regions have no complete independent visual reference. Nine readable regions are a limited subset, not the full lyric.',
    outside_region_note:'Unmatched observations are not automatically OCR spelling errors: they may be non-caption text or manual geometry omissions. They require pixel-only adjudication; their increase is not counted as accuracy gain.',
    partial_span_note:'Exact in-order preservation of certain spans is a recall diagnostic, not full-line CER and not proof that intervening words are correct.'};
  return {matching:{criterion:'Each prediction assigned to the greatest-IoU annotated rectangle if above threshold; deterministic reference-order tie break; no text-dependent matching.',threshold,reading_order:'y then x for vertical, x then y for horizontal; all assigned outputs retained, no confidence/reference best-of selection'},summary,frames,regions};
}
async function main() {
  const flags=new Map();
  for(let i=2;i<process.argv.length;i+=2) { assert(process.argv[i]?.startsWith('--') && process.argv[i+1]); flags.set(process.argv[i].slice(2),process.argv[i+1]); }
  for(const key of flags.keys())assert(['protocol','protocol-sha','reference','reference-sha','output'].includes(key),'Unknown flag: '+key);
  for(const key of ['protocol','protocol-sha','reference','reference-sha','output'])assert(flags.has(key),'Required: --'+key);
  const protocolPath=path.resolve(flags.get('protocol')),root=path.dirname(protocolPath);
  const p=await fs.readFile(protocolPath),r=await fs.readFile(path.resolve(flags.get('reference')));
  assert.equal(sha(p),flags.get('protocol-sha'));
  assert.equal(sha(r),flags.get('reference-sha'));
  const protocol=JSON.parse(p),reference=JSON.parse(r),arms=[];
  for(const arm of protocol.arms) {
    const resultBytes=await fs.readFile(arm.output_path),executionBytes=await fs.readFile(path.join(root,'results',arm.id+'-execution.json'));
    const execution=JSON.parse(executionBytes),result=JSON.parse(resultBytes);
    validateExecutionBinding(protocol,arm,sha(p),resultBytes,result,execution);
    arms.push({id:arm.id,result_sha256:sha(resultBytes),execution_receipt_sha256:sha(executionBytes),execution_exit_code:execution.observed_exit_code,
      primary_geometry:scoreArm(protocol,reference,result,execution,.1),geometry_sensitivity_025:scoreArm(protocol,reference,result,execution,.25)});
  }
  const report={schema_version:1,protocol_sha256:sha(p),reference_sha256:sha(r),scorer_sha256:sha(await fs.readFile(fileURLToPath(import.meta.url))),
    scope:'One previously seen private video. Independent Astra pixel-only reference, not human reviewed or a human gold standard. No inference, no text corrections, no private transcripts reproduced here. Main CER is restricted to nine fully readable regions.',arms};
  const output=path.resolve(flags.get('output'));await fs.writeFile(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({output,arms:arms.map(a=>({id:a.id,...a.primary_geometry.summary}))},null,2));
}
if(process.argv[1] && import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)main().catch(e=>{console.error(e.stack);process.exitCode=1;});
