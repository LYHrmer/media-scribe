# Qwen Web WASM 生命周期与分段研究源码 / Research source

这是2026-10-14的独立研究诊断源码，不是正式产品的新默认模型。归档只包含冻结的协议、JavaScript源码、无模型测试和本说明，不包含模型、PCM、真实参考答案、完整转写、运行结果或日志。测试代码中的文字是明确的夹具占位值，不是实验媒体答案。

This archive contains frozen diagnostic protocols, JavaScript source, model-free tests and this README. It contains no models, media, real reference transcripts, inference results or logs. It is a research package, not a production browser integration.

## 归档时状态 / Status at packaging

| 版本 | 状态 | 含义 |
| --- | --- | --- |
| `v1-frozen/` | 三例诊断2/3完成；最长42.973625s英文fresh Worker仍abort | 新建Worker本身不足以解决长文件。另发现停止流程可能被checkpoint磁盘I/O阻塞；正常串行推理证据与该边界缺陷分别记录 |
| `v2/` | 仅修复监督器安全边界，20项无模型自测通过，未运行ASR | 立即terminate并启动watchdog，不等checkpoint；监控/报告I/O有界；无法确认线程退出时直接结束整个诊断进程 |
| `v3/` | 分段候选准备完成，39项无模型自测及31份输入/48段规划核验通过；实际模型结果待单独报告 | 每段不超过24秒，每段新建Worker；不能把准备完成写成稳定性或准确率通过 |

The original whole-file 1280/512 run and these derived protocols must not be pooled. Worker restarts and segments are not new independent recordings. A successful model-free test is not an ASR accuracy result. Native or prior whole-file text is never substituted for new Web WASM outputs.

v1三例顺序固定为 `meli-m00a-zh`、`meli-f01b-zh`、最长 `meli-accent-final-f94a-en`。最长例的失败只有 `Aborted()`，不能声称已确诊OOM。v1原始文件未修改，`v1-frozen/`是逐字节快照。

## 冻结指纹 / Frozen protocol fingerprints

| 文件 | SHA-256 |
| --- | --- |
| `v1-frozen/protocol-frozen.json` | `a47c6688b2b9e436ec8f4a1db95eddb5413475228de6fbbbd4346b1136140af9` |
| `v2/protocol-frozen.json` | `d1b64ded88d75a032cd298ee4976cd8b0b367a144e323cca1029cbbd90c6484f` |
| `v3/protocol-frozen.json` | `f2fa3b0aae1f3410c36cf8037a0edf597e49ff63719e7158524d1cd39d127db8` |
| `v3/segmentation-plans-frozen.json` | `40fae01e77b48367bade705ce0c677ff62ce84b6362f514cba5bcd7aaed27246` |

每版协议内的`code_files`固定该版源码与测试的SHA-256。原始`original-run-qwen-web-wasm.mjs`在三版中均逐字节不变，SHA-256为 `51433db6d36340339124e61d134e700f0291f9e444701c6031ffea79d599025b`。归档的`SOURCE_MANIFEST.json`列出全部成员指纹；协议里的selftest日志哈希用于审计，日志本身不公开打包。

## 运行环境与不运行模型的检查

本轮使用Linux、Node v24.19.0。纯JavaScript代码没有npm依赖。资源采样读取Linux cgroup v2；其他系统这些字段可为null，并未宣称实机兼容性通过。

```bash
node --test v2/tests/lifecycle.test.mjs
node --test v3/tests/*.test.mjs
```

这些测试使用短小本地夹具，包括一个自行写的WASM循环来检查父线程取消，不加载官方runtime、模型或媒体。v2额外验证checkpoint拒绝/永不返回时仍能终止线程。v3验证边界、每sample完整覆盖、原始字节重组、SHA、空格拼接及失败分母。

## 真实诊断的前提 / Actual-inference prerequisites

需要另行准备固定模型和runtime；同仓库研究包的`download-qwen-int8.py`及`download-qwen-web-runtime.py`提供固定来源、版本和SHA校验。核心来源为：

- 官方runtime：`https://pub.dev/api/archives/sherpa_onnx_web-1.13.8.tar.gz`，归档SHA-256 `e25a3813eb080636280b23dd4b0098252902675158b66dceda1efba061adf5d7`。
- Qwen0.6B INT8官方发行：`https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-qwen3-asr-0.6B-int8-2026-03-25.tar.bz2`，按协议中的6个文件清单逐项核验，总计987,015,347字节。

推理输入仅含七字段：`id`、`language`、`pcm_path`、`pcm_sha256`、`sample_rate`、`audio_seconds`、`split`。只接受固定31例、固定顺序和原PCM，不接受参考答案、热词、字幕或额外字段。

**路径限制：** 这是原实验的字节保真存档。原始输入清单的SHA也包含其路径字符串；归档不含原音和该私有清单。更换本地路径后，原runner会拒绝不匹配的清单，不能把它宣传为对任意音频开箱即用。跨机器复现应另建可审计的派生协议，只适配路径并逐项保留音频hash、顺序、时长及设置，不能改这份冻结记录后声称原协议未变。

The original input-manifest hash includes local path strings. This archive is byte-faithful research source, not a self-contained media benchmark. A different machine needs an explicitly versioned path-only protocol adaptation preserving all PCM hashes and case order; the frozen original will reject a changed manifest.

## v3固定算法与命令

只有当剩余音频超过24秒时，在当前start后18–24秒（含端点）每100ms设候选；计算候选中心200ms原音的RMS，最小值为边界，完全相等时取更晚候选。最后任何正长度尾段均保留，少于2秒也不平衡处理。所有区间为整数sample半开区间，零重叠、零遗漏，不补静音、不做VAD或重采样。

固定31例规划为48段。最长录音在23.4秒分界，得到23.4秒与19.573625秒两段。每段均使用原始Web WASM runner、1280/512、空hotwords、显式中英文设置；父文本仅按顺序用一个ASCII空格连接原字符串，不trim、不去重、不改标点或词句。任一段失败/缺失则父文件失败，只有部分文本诊断，不能宣称完整转写。

以下命令需要原始清单及已核验资产；`--verify-only`不创建模型或输出目录：

```bash
cd v3
node scripts/run-worker-lifecycle.mjs \
  --cases /absolute/path/original-all-inference.json \
  --output-dir /absolute/path/new-longest-diagnostic \
  --model-dir /absolute/path/qwen3-asr-0.6B-int8 \
  --runtime-dir /absolute/path/web-runtime \
  --suite longest1 --verify-only
```

真正运行时移除`--verify-only`。先独立执行`--suite longest1`；只有该诊断可完成后，另用全新的输出目录执行`--suite all31`。两份结果不可拼接补齐，不允许从多次结果挑较好的文字。输出目录存在时会拒绝覆盖。

每份父录音保留分段规划、每段原runner报告、生命周期报告、终态及父拼接artifact。原始报告仍记录引擎内置重复尾部保护；这些不是完整未经处理的decoder轨迹。

## 退出、资源与评分边界

父线程每次仅创建一个Worker。收到原runner最终清理/报告保存完成后，父线程terminate并等待exit，随后才允许下一段。主动terminate通常产生线程退出码1；它与`runner_exit_code`分别记录，不能据线程退出码1将成功推理误判为失败。缺报告、清理错误、hash/参数不匹配、超时和未确认退出均不能算成功。

Node线程共享一个OS进程。RSS是整个进程数值，线程退出与RSS回落分别观察；ArrayBuffer/WASM资源不因JS堆限制而自动受限，全局OOM仍可能终止父进程。进程死亡可能仅留下running检查点，这属于未完成，不能补写为成功。官方语义来源：

- `https://nodejs.org/download/release/v24.19.0/docs/api/worker_threads.html#workerterminate`
- `https://nodejs.org/download/release/v24.19.0/docs/api/process.html#processmemoryusage`

这不是独立OS进程隔离，也不是真浏览器/手机端验收。模型下载、手机内存、音视频解码、界面取消恢复和真实浏览器Worker仍需另外验证。

评分只能在各批终态与实际进程退出码确认后进行。v3以父录音为单位核对所有段的退出、offset、PCM/hash和精确空格拼接，再将同批新生成文本交给独立CER/WER评分器；31父文件仍是31份录音，48段不是48个独立样本。三例旧诊断、最长一例新诊断、全31及native结果分开保留，不能拼接或混池。真实参考仅由独立评分流程读取，不传给推理线程。
