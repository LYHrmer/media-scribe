import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { assessCase, atomicJson, loadCases, readJsonOrNull, validateCaseObject, validateFrozenOrder } from '../scripts/lifecycle-common.mjs';
import { runOneWorker } from '../scripts/worker-supervisor.mjs';

const expected = { id: 'fixture-case', language: 'chinese', pcm_sha256: 'a'.repeat(64), audio_seconds: 1 };
const fakeResources = async () => ({ at: new Date().toISOString(), fixture: true });
async function fixture(mode, options = {}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'qwen-lifecycle-fixture-'));
  const reportPath = path.join(dir, 'report.json');
  const record = await runOneWorker({ workerUrl: new URL('./fixture-worker.mjs', import.meta.url),
    workerData: { mode, reportPath, expected }, checkpointPath: path.join(dir, 'lifecycle.json'),
    logPrefix: path.join(dir, 'worker'), timeoutMs: 500, terminationTimeoutMs: 3000,
    sampleMs: 20, resourceSnapshot: fakeResources, ...options });
  const report = await readJsonOrNull(reportPath);
  const saved = await readJsonOrNull(path.join(dir, 'lifecycle.json'));
  assert.equal(saved.exit_confirmed, true);
  await fs.rm(dir, { recursive: true });
  return { record, report, assessment: assessCase(record, report, expected) };
}

test('strict seven-field validation rejects reference, missing keys and nonfinite duration', () => {
  const valid = { ...expected, sample_rate: 16000, split: 'test', pcm_path: '/fixture.f32' };
  validateCaseObject(valid);
  assert.throws(() => validateCaseObject({ ...valid, reference: 'forbidden' }), /seven fields/);
  const missing = { ...valid }; delete missing.split;
  assert.throws(() => validateCaseObject(missing), /seven fields/);
  assert.throws(() => validateCaseObject({ ...valid, audio_seconds: NaN }), /Duration/);
  assert.throws(() => validateCaseObject({ ...valid, language: 'auto' }), /Explicit/);
});

test('fixed 31 order cannot be shuffled, substituted or shortened', () => {
  const rows = Array.from({ length: 31 }, (_, i) => ({ ...expected, id: `f${i}`, sample_rate: 16000, split: 'test' }));
  validateFrozenOrder(rows, structuredClone(rows));
  assert.throws(() => validateFrozenOrder([rows[1], rows[0], ...rows.slice(2)], rows), /Frozen order/);
  assert.throws(() => validateFrozenOrder(rows.slice(1), rows), /31/);
});

test('manifest rejects references before reading PCM', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'qwen-manifest-fixture-'));
  const filename = path.join(dir, 'input.json');
  await fs.writeFile(filename, JSON.stringify({ cases: [{ ...expected, pcm_path: '/nonexistent', sample_rate: 16000, split: 'test', reference: 'forbidden' }] }));
  await assert.rejects(loadCases(filename), /seven fields/);
  await fs.rm(dir, { recursive: true });
});

test('two successful fixtures have separate threads, awaited exit, maximum concurrency one', async () => {
  let active = 0, maximum = 0;
  const onActive = delta => { active += delta; maximum = Math.max(maximum, active); };
  const one = await fixture('complete', { onActive });
  assert.equal(active, 0);
  const two = await fixture('complete', { onActive });
  assert.equal(active, 0); assert.equal(maximum, 1);
  assert.notEqual(one.record.thread_id, two.record.thread_id);
  assert(one.record.worker_exited_at <= two.record.started_at);
  for (const result of [one, two]) {
    assert.equal(result.assessment.status, 'complete');
    assert.equal(result.record.termination_reason, 'runner_finalized');
    assert.equal(result.record.worker_exit_code, 1, 'Explicit terminate yields expected 1');
    assert.equal(result.record.terminal_message.runner_exit_code, 0);
  }
});

for (const mode of ['throw', 'exit7', 'exit0-no-result', 'runner-failed', 'cleanup-error', 'wrong-id', 'corrupt-report']) {
  test(`fixture ${mode} is never a successful transcription`, async () => {
    const result = await fixture(mode);
    assert.equal(result.assessment.status, 'failed');
    if (mode === 'exit7') assert.equal(result.record.worker_exit_code, 7);
    if (mode === 'exit0-no-result') assert.equal(result.record.worker_exit_code, 0);
    if (mode === 'cleanup-error') assert(result.assessment.reasons.includes('recognizer_cleanup_error'));
  });
}

for (const mode of ['timeout-init', 'busy-js', 'busy-wasm']) {
  test(`parent timeout terminates ${mode} without relying on child finally`, async () => {
    const result = await fixture(mode);
    assert.equal(result.record.termination_reason, 'case_timeout');
    assert.equal(result.record.exit_confirmed, true);
    assert.equal(result.assessment.status, 'failed');
    assert(result.record.phases.length > 0);
  });
}

test('parent cancellation interrupts synchronous WASM and cannot become complete', async () => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 250);
  const result = await fixture('busy-wasm', { signal: controller.signal, timeoutMs: 2000 });
  clearTimeout(timer);
  assert.equal(result.record.termination_reason, 'cancelled');
  assert.equal(result.assessment.status, 'failed');
});

test('pre-cancelled request never creates a Worker', async () => {
  const controller = new AbortController(); controller.abort();
  let active = 0;
  await assert.rejects(runOneWorker({ signal: controller.signal, onActive: () => active++ }), /Cancelled before/);
  assert.equal(active, 0);
});

test('failure to persist initial checkpoint prevents Worker creation', async () => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'qwen-checkpoint-fixture-'));
  let active = 0;
  await assert.rejects(runOneWorker({ checkpointPath: path.join(dir, 'missing', 'file.json'),
    resourceSnapshot: fakeResources, onActive: () => active++ }));
  assert.equal(active, 0); await fs.rm(dir, { recursive: true });
});

test('late final message never overrides a timeout classification', () => {
  const result = assessCase({ exit_confirmed: true, worker_exit_code: 1,
    termination_reason: 'case_timeout', terminal_message: { type: 'runner_finalized', runner_exit_code: 0, status: 'complete' } },
    { status: 'complete' }, expected);
  assert.equal(result.status, 'failed'); assert(result.reasons.includes('case_timeout'));
});

for (const failure of ['never-resolves', 'rejects']) {
  test(`checkpoint ${failure} cannot block Worker termination or hang supervisor`, async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'qwen-checkpoint-fault-'));
    let writes = 0, active = 0, exitSeen = false;
    const started = performance.now();
    const checkpointWriter = async (filename, value) => {
      if (++writes === 1) return atomicJson(filename, value);
      if (failure === 'rejects') throw new Error('fixture disk write failed');
      return new Promise(() => {}); // Deliberately never resolves, no real I/O.
    };
    await assert.rejects(runOneWorker({
      workerUrl: new URL('./fixture-worker.mjs', import.meta.url),
      workerData: { mode: 'busy-wasm', reportPath: path.join(dir, 'report.json'), expected },
      checkpointPath: path.join(dir, 'lifecycle.json'), logPrefix: path.join(dir, 'worker'),
      timeoutMs: 120, terminationTimeoutMs: 1000, ioTimeoutMs: 80, sampleMs: 10,
      resourceSnapshot: fakeResources, checkpointWriter,
      onActive: delta => { active += delta; if (delta === -1) exitSeen = true; },
    }), error => {
      assert.equal(error.workerRecord.exit_confirmed, true);
      assert.equal(error.workerRecord.status, 'supervisor_failed');
      return true;
    });
    assert(exitSeen); assert.equal(active, 0);
    assert(performance.now() - started < 2000, 'No unbounded catch/finally wait');
    await fs.rm(dir, { recursive: true });
  });
}
