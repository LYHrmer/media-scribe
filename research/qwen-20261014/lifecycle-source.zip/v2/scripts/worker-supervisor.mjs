import { createWriteStream } from 'node:fs';
import { finished } from 'node:stream/promises';
import { Worker } from 'node:worker_threads';
import { atomicJson, readJsonOrNull, resources, withDeadline } from './lifecycle-common.mjs';

export async function runOneWorker({ workerUrl, workerData, checkpointPath, logPrefix,
  timeoutMs = 600_000, terminationTimeoutMs = 10_000, sampleMs = 1_000,
  resourceSnapshot = resources, onActive = () => {}, signal,
  ioTimeoutMs = 5000, checkpointWriter = atomicJson,
  onTerminationUnconfirmed = () => {} }) {
  if (signal?.aborted) throw new Error('Cancelled before Worker creation');
  const record = { started_at: new Date().toISOString(), status: 'running',
    termination_reason: null, exit_confirmed: false, worker_exit_code: null,
    phases: [], resource_samples: [], console_bytes: { stdout: 0, stderr: 0 },
    resource_before_worker: await withDeadline(resourceSnapshot(), ioTimeoutMs, 'Initial resource snapshot') };
  await withDeadline(checkpointWriter(checkpointPath, record), ioTimeoutMs, 'Initial checkpoint');
  let worker, sampling = false, stopping = false, timeout, interval;
  let terminationWatchdog, finishResolve, finishReject, samplePromise = Promise.resolve();
  const completion = new Promise((resolve, reject) => { finishResolve = resolve; finishReject = reject; });
  const stdout = createWriteStream(logPrefix + '.stdout.log', { flags: 'wx' });
  const stderr = createWriteStream(logPrefix + '.stderr.log', { flags: 'wx' });
  let saveChain = Promise.resolve();
  const checkpoint = () => {
    const snapshot = structuredClone(record);
    saveChain = saveChain.then(() => withDeadline(
      Promise.resolve().then(() => checkpointWriter(checkpointPath, snapshot)), ioTimeoutMs, 'Lifecycle checkpoint'));
    return saveChain;
  };
  let terminatePromise;
  let logCompletion;
  let exitResolve;
  const exitPromise = new Promise(resolve => { exitResolve = resolve; });
  const requestStop = reason => {
    if (stopping) return;
    stopping = true; record.termination_reason = reason;
    record.termination_requested_at = new Date().toISOString();
    clearTimeout(timeout); clearInterval(interval);
    // Termination must not depend on a disk write, a resource read, or child
    // finally. Start the watchdog before any asynchronous bookkeeping.
    terminationWatchdog = setTimeout(() => {
      if (record.exit_confirmed) return;
      record.status = 'termination_unconfirmed';
      const error = new Error('Worker termination not confirmed; no next case may start');
      finishReject(error);
      onTerminationUnconfirmed(record); // CLI exits the whole process immediately.
    }, terminationTimeoutMs);
    try {
      if (!record.exit_confirmed) {
        terminatePromise = worker.terminate();
        terminatePromise.then(code => { record.terminate_promise_exit_code = code; }, error => {
          record.terminate_error = String(error); finishReject(error);
        });
      } else clearTimeout(terminationWatchdog);
    } catch (error) { finishReject(error); }
    void checkpoint().catch(error => {
      record.persistence_error = String(error); finishReject(error);
    });
  };
  const onAbort = () => { void requestStop('cancelled'); };
  const poll = () => {
    if (sampling || record.exit_confirmed) return;
    sampling = true;
    samplePromise = (async () => {
      const sample = await withDeadline(resourceSnapshot(), ioTimeoutMs, 'Resource sample');
      const report = await withDeadline(readJsonOrNull(workerData.reportPath), ioTimeoutMs, 'Runner checkpoint read');
      sample.runner_stage = report?.stage ?? null;
      sample.runner_status = report?.status ?? null;
      sample.runner_logged_messages = report?.logs?.length ?? 0;
      if (record.resource_samples.length < 1200) record.resource_samples.push(sample);
      else { record.resource_samples.shift(); record.resource_samples.push(sample); record.earlier_samples_dropped = (record.earlier_samples_dropped || 0) + 1; }
      if (report?.stage && report.stage !== record.last_observed_runner_stage) {
        record.last_observed_runner_stage = report.stage;
        record.phases.push({ at: sample.at, runner_stage: report.stage });
      }
      await checkpoint();
    })().catch(error => { record.monitor_error = String(error); void requestStop('supervisor_monitor_failed'); })
      .finally(() => { sampling = false; });
  };
  try {
    worker = new Worker(workerUrl, { workerData, stdout: true, stderr: true,
      execArgv: ['--experimental-vm-modules'] });
    record.thread_id = worker.threadId;
    onActive(1);
    worker.stdout.on('data', chunk => { record.console_bytes.stdout += chunk.length; });
    worker.stderr.on('data', chunk => { record.console_bytes.stderr += chunk.length; });
    worker.stdout.pipe(stdout); worker.stderr.pipe(stderr);
    logCompletion = Promise.all([finished(stdout), finished(stderr)]);
    logCompletion.catch(error => { record.log_write_error = String(error); void requestStop('supervisor_log_failed'); });
    worker.on('message', message => {
      if (message?.type === 'phase') record.phases.push({ at: new Date().toISOString(), ...message });
      else if (['runner_finalized', 'wrapper_failed'].includes(message?.type)) {
        if (record.terminal_message) { record.duplicate_terminal_message = true; void requestStop('duplicate_terminal_message'); return; }
        record.terminal_message = message;
        void requestStop(message.type);
      } else { record.unknown_worker_message = true; void requestStop('worker_protocol_error'); }
    });
    worker.on('error', error => {
      record.worker_error = { name: error.name, message: error.message, stack: error.stack };
      void requestStop('worker_error');
    });
    worker.once('exit', code => {
      record.exit_confirmed = true; record.worker_exit_code = code;
      record.worker_exited_at = new Date().toISOString();
      clearTimeout(terminationWatchdog);
      onActive(-1); exitResolve(); finishResolve();
    });
    timeout = setTimeout(() => { void requestStop('case_timeout'); }, timeoutMs);
    signal?.addEventListener('abort', onAbort, { once: true });
    if (signal?.aborted) onAbort();
    interval = setInterval(poll, sampleMs);
    poll();
    await completion;
    clearInterval(interval); clearTimeout(timeout); clearTimeout(terminationWatchdog);
    await withDeadline(samplePromise, ioTimeoutMs * 3, 'Monitor completion');
    if (terminatePromise) await withDeadline(terminatePromise, terminationTimeoutMs, 'Terminate completion');
    await withDeadline(logCompletion, ioTimeoutMs, 'Log close');
    record.status = 'worker_exited';
    record.resource_after_worker_exit = await withDeadline(resourceSnapshot(), ioTimeoutMs, 'Final resource sample');
    await checkpoint();
    return record;
  } catch (error) {
    clearInterval(interval); clearTimeout(timeout);
    if (worker && !record.exit_confirmed) {
      requestStop('supervisor_failed');
      await withDeadline(exitPromise, terminationTimeoutMs, 'Emergency exit confirmation').catch(() => {});
    }
    if (record.exit_confirmed) clearTimeout(terminationWatchdog);
    record.status = record.exit_confirmed ? 'supervisor_failed' : 'termination_unconfirmed';
    record.supervisor_error = { name: error.name, message: error.message, stack: error.stack };
    await withDeadline(samplePromise, ioTimeoutMs * 3, 'Failed monitor cleanup').catch(() => {});
    await withDeadline(checkpoint(), ioTimeoutMs, 'Failed checkpoint attempt').catch(() => {});
    stdout.destroy(); stderr.destroy();
    // A non-terminated Worker must never be followed by another model Worker.
    error.workerRecord = record;
    throw error;
  } finally {
    signal?.removeEventListener('abort', onAbort);
    if (record.exit_confirmed) {
      worker.removeAllListeners();
      worker.stdout.removeAllListeners(); worker.stderr.removeAllListeners();
    }
  }
}
