#!/usr/bin/env node
// This supervisor never instantiates a model. Each serial Worker imports the
// frozen actual-Web-WASM runner once for one unmodified full PCM input.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { assessCase, atomicJson, fileSha, loadCases, ORIGINAL_SHA,
  readJsonOrNull, resources, SETTINGS, validateFrozenOrder, withDeadline } from './lifecycle-common.mjs';
import { runOneWorker } from './worker-supervisor.mjs';

function parseArgs(values) {
  const args = {};
  for (let i = 0; i < values.length; i++) {
    const key = values[i];
    if (['--verify-only', '--help'].includes(key)) args[key.slice(2)] = true;
    else if (['--cases', '--output-dir', '--model-dir', '--runtime-dir', '--suite'].includes(key)) {
      assert(values[i + 1] && !values[i + 1].startsWith('--'), `Missing ${key}`);
      assert(!args[key.slice(2)], `Duplicate ${key}`); args[key.slice(2)] = values[++i];
    } else throw Error(`Unknown argument ${key}`);
  }
  return args;
}
const args = parseArgs(process.argv.slice(2));
if (args.help) {
  console.log('node scripts/run-worker-lifecycle.mjs --cases original31.json --output-dir NEW_DIR --model-dir MODELS --runtime-dir WEB_RUNTIME [--suite diagnostic3|all31] [--verify-only]');
  process.exit(0);
}
for (const key of ['cases', 'output-dir', 'model-dir', 'runtime-dir']) assert(args[key], `Missing --${key}`);
const root = path.dirname(fileURLToPath(new URL('../protocol-frozen.json', import.meta.url)));
const protocolPath = path.join(root, 'protocol-frozen.json');
const protocol = JSON.parse(await fs.readFile(protocolPath, 'utf8'));
const persist = (filename, value) => withDeadline(atomicJson(filename, value), protocol.io_timeout_ms, 'Parent report write');
const sampleResources = () => withDeadline(resources(), protocol.io_timeout_ms, 'Parent resource sample');
const manifestPath = path.resolve(args.cases), modelDir = path.resolve(args['model-dir']);
const runtimeDir = path.resolve(args['runtime-dir']), outputDir = path.resolve(args['output-dir']);
const allCases = await loadCases(manifestPath);
validateFrozenOrder(allCases, protocol.cases_in_frozen_order);
const suite = args.suite || 'all31';
assert(['diagnostic3', 'all31'].includes(suite), 'Unknown frozen suite');
const cases = suite === 'all31' ? allCases : protocol.diagnostic3_ids.map(id => {
  const c = allCases.find(item => item.id === id); assert(c, `Missing fixed diagnostic ${id}`); return c;
});
assert.equal(await fileSha(manifestPath), protocol.original_input_manifest_sha256, 'Use the unchanged original 31-case manifest');
assert.deepEqual(protocol.settings, SETTINGS);
const codeProvenance = [];
for (const item of protocol.code_files) {
  const filename = path.join(root, item.path);
  assert.equal(await fileSha(filename), item.sha256, `Diagnostic source changed: ${item.path}`);
  codeProvenance.push(item);
}
assert.equal(await fileSha(new URL('./original-run-qwen-web-wasm.mjs', import.meta.url)), ORIGINAL_SHA);
const manifests = {};
for (const [kind, dir, filename, expectedSha, count] of [
  ['model', modelDir, 'download-manifest.json', protocol.model_manifest_sha256, 6],
  ['runtime', runtimeDir, 'provenance.json', protocol.runtime_manifest_sha256, 3],
]) {
  const manifestFile = path.join(dir, filename);
  assert.equal(await fileSha(manifestFile), expectedSha, `Pinned ${kind} manifest changed`);
  const manifest = JSON.parse(await fs.readFile(manifestFile, 'utf8'));
  assert.equal(manifest.files.length, count);
  for (const item of manifest.files) {
    const filename = path.resolve(dir, item.path || item.file);
    assert(filename.startsWith(dir + path.sep));
    assert.equal((await fs.stat(filename)).size, item.bytes);
    assert.equal(await fileSha(filename), item.sha256, `Asset changed: ${filename}`);
  }
  manifests[kind] = manifest;
}
if (args['verify-only']) {
  console.log(JSON.stringify({ verified: true, suite, cases: cases.length, frozen_order: true,
    exact_seven_fields: true, settings: SETTINGS, wasm_initialized: false,
    inference_started: false, workers_started: 0, output_created: false }));
  process.exit(0);
}

// Exclusive directory creation prevents any overwrite of earlier evidence.
await fs.mkdir(path.dirname(outputDir), { recursive: true });
await fs.mkdir(outputDir);
const summaryPath = path.join(outputDir, 'summary.json');
const summary = {
  schema_version: 1, created_at: new Date().toISOString(), status: 'running',
  suite, suite_note: 'diagnostic3 and all31 are separately reported runs. Never concatenate them, deduplicate to best text, or count restarts as independent samples.',
  scope: 'Actual official Web WASM in one newly created Node worker_threads Worker per file. Its inner VM remains browser-shaped. Not independent OS processes, not browser/mobile validation.',
  experiment_kind: 'Derived lifecycle diagnostic on the same 31 fixed recordings. Worker restarts do not create new independent samples.',
  output_semantics: 'Unmodified Sherpa engine-returned text; includes built-in repetition-tail protection. No reference text, audio trimming, token correction, VAD or best-of-protocol selection.',
  protocol_sha256: await fileSha(protocolPath), original_input_manifest_sha256: await fileSha(manifestPath),
  code_files: codeProvenance, model: manifests.model, runtime: manifests.runtime, settings: SETTINGS,
  resource_semantics: 'Parent and Worker RSS refer to the same whole process. Isolate external/heap figures differ. cgroup counters are shared. Thread exit does not promise immediate RSS reduction or protect the parent from global OOM.',
  cancellation_policy: 'Parent records cancellation and terminates the active Worker; no next Worker until exit is confirmed. Forced termination need not execute worker finally. Host/process death can leave the last atomic checkpoint running; that is incomplete, never success.',
  planned_cases: cases.map(c => ({ id: c.id, pcm_sha256: c.pcm_sha256 })),
  cases: [], active_case: null, resource_before_batch: await sampleResources(),
};
const controller = new AbortController();
let interruptedSignal;
const stopForSignal = signal => { interruptedSignal = signal; controller.abort(); };
const onInt = () => stopForSignal('SIGINT'), onTerm = () => stopForSignal('SIGTERM');
process.on('SIGINT', onInt); process.on('SIGTERM', onTerm);
await persist(summaryPath, summary);
try {
  for (let index = 0; index < cases.length; index++) {
    if (controller.signal.aborted) break;
    const c = cases[index], prefix = String(index + 1).padStart(2, '0');
    const caseDir = path.join(outputDir, prefix); await fs.mkdir(caseDir);
    const oneManifest = path.join(caseDir, 'input.json');
    const reportPath = path.join(caseDir, 'runner-report.json');
    const checkpointPath = path.join(caseDir, 'lifecycle.json');
    await persist(oneManifest, { cases: [c] });
    summary.active_case = { index, id: c.id, directory: prefix };
    await persist(summaryPath, summary);
    const record = await runOneWorker({ workerUrl: new URL('./case-worker.mjs', import.meta.url),
      workerData: { manifestPath: oneManifest, reportPath, modelDir, runtimeDir },
      checkpointPath, logPrefix: path.join(caseDir, 'worker'), signal: controller.signal,
      timeoutMs: protocol.case_timeout_ms, terminationTimeoutMs: protocol.termination_timeout_ms,
      sampleMs: protocol.resource_sample_interval_ms, ioTimeoutMs: protocol.io_timeout_ms,
      // No awaiting I/O here. Last atomic parent checkpoint remains incomplete.
      onTerminationUnconfirmed: () => process.exit(2) });
    const report = await readJsonOrNull(reportPath);
    const assessment = assessCase(record, report, c);
    const reportSha = report ? await fileSha(reportPath) : null;
    if (record.terminal_message?.report_sha256 !== reportSha) {
      assessment.status = 'failed'; assessment.reasons.push('final_report_hash_mismatch');
    }
    const row = { id: c.id, index, status: assessment.status, reasons: assessment.reasons,
      pcm_sha256: c.pcm_sha256, language: c.language, audio_seconds: c.audio_seconds,
      worker_exit_code: record.worker_exit_code, runner_exit_code: record.terminal_message?.runner_exit_code ?? null,
      termination_reason: record.termination_reason, thread_id: record.thread_id,
      exit_confirmed: record.exit_confirmed, report_sha256: reportSha,
      runner_report: path.relative(outputDir, reportPath), lifecycle_report: path.relative(outputDir, checkpointPath),
      runner_status: report?.status ?? null, runner_stage: report?.stage ?? null,
      cleanup_error: report?.cleanup_error ?? null,
      ...(report?.cases?.[0] ? { engine_output: report.cases[0] } : {}),
      resource_after_worker_exit: record.resource_after_worker_exit };
    summary.cases.push(row); summary.active_case = null;
    await persist(summaryPath, summary);
    console.log(JSON.stringify({ index: index + 1, id: c.id, status: row.status,
      reasons: row.reasons, termination_reason: row.termination_reason, worker_exit_code: row.worker_exit_code }));
  }
  summary.status = controller.signal.aborted ? 'cancelled'
    : summary.cases.length === cases.length && summary.cases.every(c => c.status === 'complete') ? 'complete' : 'failed';
} catch (error) {
  summary.status = 'supervisor_failed';
  summary.error = { name: error.name, message: error.message, stack: error.stack };
  if (error.workerRecord) summary.active_worker_failure = error.workerRecord;
} finally {
  process.removeListener('SIGINT', onInt); process.removeListener('SIGTERM', onTerm);
  summary.finished_at = new Date().toISOString();
  summary.completed_cases = summary.cases.filter(c => c.status === 'complete').length;
  summary.failed_cases = summary.cases.filter(c => c.status === 'failed').length;
  summary.unfinished_cases = cases.length - summary.cases.length;
  summary.interrupted_signal = interruptedSignal ?? null;
  summary.resource_after_batch = await sampleResources();
  await persist(summaryPath, summary);
  if (summary.status !== 'complete') process.exitCode = 1;
  // If termination could not be confirmed, ending this entire diagnostic Node
  // process is safer than allowing another Worker or leaving inference alive.
  if (summary.active_worker_failure && !summary.active_worker_failure.exit_confirmed) process.exit(2);
}
