// TEST FIXTURE ONLY. Never loads a model, audio, official runtime or ASR runner.
import fs from 'node:fs/promises';
import { parentPort, workerData, threadId } from 'node:worker_threads';
import { fileSha, ORIGINAL_SHA, SETTINGS } from '../scripts/lifecycle-common.mjs';

const { mode, reportPath, expected } = workerData;
if (mode === 'throw') throw new Error('fixture uncaught exception');
if (mode === 'exit7') process.exit(7);
if (mode === 'exit0-no-result') process.exit(0);
const stage = mode === 'timeout-init' ? 'initializing_actual_wasm' : 'decoding:fixture:1';
await fs.writeFile(reportPath, JSON.stringify({ fixture: true, status: 'running', stage }));
parentPort.postMessage({ type: 'phase', phase: stage, thread_id: threadId });
if (mode === 'timeout-init') await new Promise(() => { setInterval(() => {}, 60_000); });
if (mode === 'busy-js') { while (true) { /* Test parent cancellation of synchronous work. */ } }
if (mode === 'busy-wasm') {
  // Tiny locally-authored module: (func (export "loop") (loop (br 0))).
  const bytes = new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,
    3,2,1,0,7,8,1,4,108,111,111,112,0,0,10,9,1,7,0,3,64,12,0,11,11]);
  const { instance } = await WebAssembly.instantiate(bytes);
  instance.exports.loop();
}
const row = { ...expected, pass: 1, status: 'complete', text: 'TEST FIXTURE ONLY', result: { text: 'TEST FIXTURE ONLY' } };
if (mode === 'wrong-id') row.id = 'wrong-id';
const report = { fixture: true, status: mode === 'runner-failed' ? 'failed' : 'complete', stage: 'complete',
  source_sha256: ORIGINAL_SHA, settings: SETTINGS, network_attempts: [], cases: [row] };
if (mode === 'cleanup-error') report.cleanup_error = 'fixture cleanup failure';
if (mode === 'corrupt-report') await fs.writeFile(reportPath, '{broken');
else await fs.writeFile(reportPath, JSON.stringify(report));
parentPort.postMessage({ type: 'runner_finalized', status: report.status,
  runner_exit_code: mode === 'runner-failed' ? 1 : 0,
  report_sha256: await fileSha(reportPath), thread_id: threadId });
setInterval(() => {}, 60_000); // Parent must terminate even after a good result.
