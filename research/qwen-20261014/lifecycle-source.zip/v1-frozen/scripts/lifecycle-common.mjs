import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';

export const ORIGINAL_SHA = '51433db6d36340339124e61d134e700f0291f9e444701c6031ffea79d599025b';
export const SETTINGS = Object.freeze({ feature_dim: 128, sample_rate: 16000, num_threads: 1,
  provider: 'cpu', max_total_len: 1280, max_new_tokens: 512, temperature: 1e-6,
  top_p: 0.8, seed: 42, hotwords: '', repeat: 1 });
const KEYS = ['audio_seconds', 'id', 'language', 'pcm_path', 'pcm_sha256', 'sample_rate', 'split'];

export async function fileSha(filename) {
  const digest = createHash('sha256');
  for await (const chunk of createReadStream(filename)) digest.update(chunk);
  return digest.digest('hex');
}

export async function atomicJson(filename, value) {
  const temp = filename + '.tmp';
  await fs.writeFile(temp, JSON.stringify(value, null, 2) + '\n');
  await fs.rename(temp, filename);
}

export function validateCaseObject(c) {
  assert(c && typeof c === 'object' && !Array.isArray(c), 'Case must be an object');
  assert.deepEqual(Object.keys(c).sort(), KEYS, 'Exactly seven fields required; no references or unknown fields');
  for (const key of ['id', 'language', 'pcm_path', 'pcm_sha256', 'split']) assert(typeof c[key] === 'string' && c[key].length, `Invalid ${key}`);
  assert(['chinese', 'english'].includes(c.language), 'Explicit Chinese or English only');
  assert.equal(c.sample_rate, 16000);
  assert(/^[a-f0-9]{64}$/.test(c.pcm_sha256), 'Invalid PCM hash');
  assert(Number.isFinite(c.audio_seconds) && c.audio_seconds > 0 && c.audio_seconds <= 42.973625, 'Duration outside frozen capacity proof');
}

export async function loadCases(filename) {
  const input = JSON.parse(await fs.readFile(filename, 'utf8'));
  assert(input && !Array.isArray(input) && Object.keys(input).length === 1 && Array.isArray(input.cases), 'Manifest must contain only cases');
  assert(input.cases.length, 'No cases');
  const seen = new Set();
  for (const c of input.cases) {
    validateCaseObject(c);
    assert(!seen.has(c.id), 'Duplicate case id'); seen.add(c.id);
    c.pcm_path = path.resolve(path.dirname(filename), c.pcm_path);
    const size = (await fs.stat(c.pcm_path)).size;
    assert(size > 0 && size % 4 === 0, 'PCM must be float32 samples');
    assert(Math.abs(size / 4 / 16000 - c.audio_seconds) <= 1 / 16000, 'PCM duration mismatch');
    assert.equal(await fileSha(c.pcm_path), c.pcm_sha256, 'PCM hash mismatch');
  }
  return input.cases;
}

export function validateFrozenOrder(cases, frozen) {
  assert.equal(cases.length, 31, 'The lifecycle diagnostic requires all original 31 cases');
  assert.equal(frozen.length, 31);
  for (let i = 0; i < cases.length; i++) {
    for (const key of ['id', 'pcm_sha256', 'audio_seconds', 'language', 'sample_rate', 'split']) {
      assert.equal(cases[i][key], frozen[i][key], `Frozen order/content changed: ${i} ${key}`);
    }
  }
}

export async function readJsonOrNull(filename) {
  try { return JSON.parse(await fs.readFile(filename, 'utf8')); } catch { return null; }
}

export async function resources() {
  const snapshot = { at: new Date().toISOString(), process: process.memoryUsage(),
    semantics: 'RSS covers the entire Node process, not one Worker; heap/external fields describe the calling isolate. cgroup values are shared with other tasks.' };
  for (const name of ['memory.current', 'memory.peak', 'memory.max', 'memory.events']) {
    try { snapshot[name] = (await fs.readFile('/sys/fs/cgroup/' + name, 'utf8')).trim(); }
    catch { snapshot[name] = null; }
  }
  return snapshot;
}

export function assessCase(record, report, expected) {
  const reasons = [];
  if (!record.exit_confirmed) reasons.push('worker_exit_unconfirmed');
  if (record.termination_reason !== 'runner_finalized') reasons.push(record.termination_reason || 'worker_ended_without_terminal_message');
  if (record.worker_error) reasons.push('worker_error');
  if (record.terminal_message?.runner_exit_code !== 0) reasons.push('runner_nonzero_exit_code');
  if (!record.terminal_message) reasons.push('missing_terminal_message');
  if (report?.status !== 'complete' || report?.stage !== 'complete') reasons.push('runner_not_complete');
  if (report?.cleanup_error) reasons.push('recognizer_cleanup_error');
  if (report?.source_sha256 !== ORIGINAL_SHA) reasons.push('runner_hash_mismatch');
  if (!Array.isArray(report?.network_attempts) || report.network_attempts.length) reasons.push('network_isolation_failed');
  if (JSON.stringify(report?.settings) !== JSON.stringify(SETTINGS)) reasons.push('settings_mismatch');
  if (report?.cases?.length !== 1) reasons.push('wrong_case_count');
  const row = report?.cases?.[0];
  if (row?.id !== expected.id || row?.pcm_sha256 !== expected.pcm_sha256 || row?.language !== expected.language
    || row?.status !== 'complete' || row?.pass !== 1 || Math.abs((row?.audio_seconds ?? 0) - expected.audio_seconds) > 1 / 16000) reasons.push('case_identity_or_terminal_status_mismatch');
  if (record.terminal_message?.status !== report?.status) reasons.push('terminal_report_mismatch');
  // A successful explicit Worker.terminate() normally yields 1, not 0.
  if (![0, 1].includes(record.worker_exit_code)) reasons.push('unexpected_worker_exit_code');
  return { status: reasons.length ? 'failed' : 'complete', reasons };
}
