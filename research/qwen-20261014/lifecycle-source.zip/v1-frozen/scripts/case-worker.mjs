// One actual official Web WASM instance per thread. The frozen runner below
// creates its original browser-shaped VM; Node is not exposed inside that VM.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { parentPort, workerData, threadId } from 'node:worker_threads';
import { fileURLToPath } from 'node:url';
import { fileSha, ORIGINAL_SHA } from './lifecycle-common.mjs';

assert(parentPort, 'This entrypoint must run in a Worker');
assert.deepEqual(Object.keys(workerData).sort(), ['manifestPath', 'modelDir', 'reportPath', 'runtimeDir']);
const runner = new URL('./original-run-qwen-web-wasm.mjs', import.meta.url);
assert.equal(await fileSha(runner), ORIGINAL_SHA);
// Keep the thread alive after the runner finalizes so the parent explicitly
// terminates it. Forced termination is not expected to run JS finally blocks.
const keepAlive = setInterval(() => {}, 60_000);
let terminal;
try {
  process.argv = [process.execPath, fileURLToPath(runner),
    '--cases', workerData.manifestPath, '--output', workerData.reportPath,
    '--model-dir', workerData.modelDir, '--runtime-dir', workerData.runtimeDir,
    '--max-total-len', '1280', '--max-new-tokens', '512', '--repeat', '1'];
  parentPort.postMessage({ type: 'phase', phase: 'importing_frozen_runner', thread_id: threadId });
  await import(runner.href);
  // The import resolves only after recognizer.free() and final report save.
  const report = JSON.parse(await fs.readFile(workerData.reportPath, 'utf8'));
  terminal = { type: 'runner_finalized', status: report.status,
    runner_exit_code: process.exitCode ?? 0, report_sha256: await fileSha(workerData.reportPath),
    cleanup_error: report.cleanup_error ?? null, thread_id: threadId,
    isolate_memory_after_runner: process.memoryUsage() };
} catch (error) {
  terminal = { type: 'wrapper_failed', runner_exit_code: process.exitCode ?? 1,
    thread_id: threadId, error: { name: error.name, message: error.message, stack: error.stack },
    isolate_memory_at_failure: process.memoryUsage() };
}
parentPort.postMessage(terminal);
// The supervisor calls terminate and awaits exit before admitting another case.
void keepAlive;
