import assert from 'node:assert/strict';
import test from 'node:test';
import { assembleParentResult, describeSegments, shaBytes } from '../scripts/segment-assembly.mjs';

function fixture() {
  const raw = Buffer.alloc(16000 * 40 * 4);
  const parent = { id: 'fixture-only', pcm_sha256: shaBytes(raw), audio_seconds: 40, language: 'chinese' };
  const plan = describeSegments(parent, raw);
  return { raw, parent, plan };
}

test('segment hashes and exact byte concatenation recover complete parent PCM', () => {
  const { raw, parent, plan } = fixture();
  assert.equal(plan.length, 2);
  const chunks = plan.map(p => raw.subarray(p.start * 4, p.end * 4));
  chunks.forEach((chunk, i) => assert.equal(shaBytes(chunk), plan[i].pcm_sha256));
  assert.equal(shaBytes(Buffer.concat(chunks)), parent.pcm_sha256);
  assert.deepEqual(Buffer.concat(chunks), raw);
});

test('assembly only inserts one ASCII space, preserving Chinese and all existing whitespace', () => {
  const { parent, plan } = fixture();
  const texts = ['甲，\n', ' 乙。'];
  const segments = plan.map((p, i) => ({ ...p, status: 'complete', engine_output: { text: texts[i] } }));
  const result = assembleParentResult(parent, 0, plan, segments);
  assert.equal(result.status, 'complete');
  assert.equal(result.text, '甲，\n  乙。');
});

test('any failed or missing segment prevents complete-file text and preserves failure denominator', () => {
  const { parent, plan } = fixture();
  const first = { ...plan[0], status: 'complete', engine_output: { text: 'fixture output' } };
  for (const segments of [[first], [first, { ...plan[1], status: 'failed' }]]) {
    const result = assembleParentResult(parent, 0, plan, segments);
    assert.equal(result.status, 'failed'); assert.equal(result.expected_segments, 2);
    assert.equal(result.completed_segments, 1); assert(!('text' in result));
    assert.equal(result.partial_text_diagnostic, 'fixture output');
  }
});

test('wrong offset/order/hash and changed parent PCM are rejected', () => {
  const { raw, parent, plan } = fixture();
  assert.throws(() => describeSegments({ ...parent, pcm_sha256: 'f'.repeat(64) }, raw));
  const segments = plan.map(p => ({ ...p, status: 'complete', engine_output: { text: '' } }));
  assert.throws(() => assembleParentResult(parent, 0, plan, segments.toReversed()));
  assert.throws(() => assembleParentResult(parent, 0, plan, [{ ...segments[0], end: segments[0].end - 1 }, segments[1]]));
  assert.throws(() => assembleParentResult(parent, 0, plan, [{ ...segments[0], pcm_sha256: 'f'.repeat(64) }, segments[1]]));
});
