import assert from 'node:assert/strict';
import test from 'node:test';
import { planPcmSegments } from '../scripts/segment-plan.mjs';

const SR = 16_000;
const MAX = 24 * SR;
const HALF_WINDOW = SR / 10;
const ranges = segments => segments.map(({ start, end }) => ({ start, end }));
const tone = samples => new Float32Array(samples).fill(1);

function silenceWindow(pcm, center) {
  pcm.fill(0, center - HALF_WINDOW, center + HALF_WINDOW);
}

function assertCoverage(segments, sampleCount) {
  assert.equal(segments[0].start, 0);
  assert.equal(segments.at(-1).end, sampleCount);
  const counts = new Uint8Array(sampleCount);
  for (let i = 0; i < segments.length; i++) {
    const { start, end } = segments[i];
    assert(Number.isInteger(start) && Number.isInteger(end));
    assert(start >= 0 && end <= sampleCount);
    assert(end > start && end - start <= MAX);
    if (i > 0) assert.equal(start, segments[i - 1].end);
    for (let j = start; j < end; j++) counts[j]++;
  }
  assert(counts.every(count => count === 1), 'Every original sample must be covered exactly once');
}

test('one sample, a short recording, and exactly 24 seconds remain one range', () => {
  for (const n of [1, 137, SR, MAX]) {
    assert.deepEqual(ranges(planPcmSegments(tone(n))), [{ start: 0, end: n }]);
  }
});

test('24 seconds plus one sample splits at 24 seconds and retains a one-sample tail', () => {
  const plan = planPcmSegments(tone(MAX + 1));
  assert.deepEqual(ranges(plan), [{ start: 0, end: MAX }, { start: MAX, end: MAX + 1 }]);
  assert.equal(plan[0].rms, 1, 'Clipped edge window uses its actual sample count');
  assertCoverage(plan, MAX + 1);
});

test('the exact minimum-power 200 ms original-audio valley determines the boundary', () => {
  const pcm = tone(30 * SR);
  const valley = 21 * SR;
  silenceWindow(pcm, valley);
  const plan = planPcmSegments(pcm);
  assert.equal(plan[0].end, valley);
  assert.equal(plan[0].rms, 0);
  assert.deepEqual(ranges(plan), [{ start: 0, end: valley }, { start: valley, end: pcm.length }]);
});

test('both 18-second and 24-second candidate endpoints are included', () => {
  for (const seconds of [18, 24]) {
    const pcm = tone(30 * SR);
    silenceWindow(pcm, seconds * SR);
    assert.equal(planPcmSegments(pcm)[0].end, seconds * SR);
  }
});

test('equal-power separated valleys choose the later candidate', () => {
  const pcm = tone(30 * SR);
  const early = 192 * (SR / 10);
  const late = 228 * (SR / 10);
  silenceWindow(pcm, early);
  silenceWindow(pcm, late);
  assert.equal(planPcmSegments(pcm)[0].end, late);
});

test('all-silent ties choose 24 seconds and preserve a tail shorter than 2 seconds', () => {
  const pcm = new Float32Array(25 * SR);
  const plan = planPcmSegments(pcm);
  assert.deepEqual(ranges(plan), [{ start: 0, end: MAX }, { start: MAX, end: 25 * SR }]);
  assert.equal(plan[0].rms, 0);
});

test('RMS uses both halves of the centered window, not only the preceding audio', () => {
  const pcm = tone(30 * SR);
  const deceptive = 19 * SR;
  pcm.fill(0, deceptive - HALF_WINDOW, deceptive);
  const quieter = 22 * SR;
  pcm.fill(0.5, quieter - HALF_WINDOW, quieter + HALF_WINDOW);
  const plan = planPcmSegments(pcm);
  assert.equal(plan[0].end, quieter);
  assert.equal(plan[0].rms, 0.5);
});

test('a clipped final candidate window is not artificially favored by a fixed denominator', () => {
  const pcm = tone(MAX + 1);
  const quieter = 22 * SR;
  pcm.fill(0.75, quieter - HALF_WINDOW, quieter + HALF_WINDOW);
  const plan = planPcmSegments(pcm);
  assert.equal(plan[0].end, quieter);
  assert.equal(plan[0].rms, 0.75);
});

test('candidate positions are relative to the current start after an early boundary', () => {
  const pcm = tone(65 * SR);
  const first = 191 * (SR / 10);
  const second = first + 203 * (SR / 10);
  silenceWindow(pcm, first);
  silenceWindow(pcm, second);
  const plan = planPcmSegments(pcm);
  assert.equal(plan[0].end, first);
  assert.equal(plan[1].end, second);
  assertCoverage(plan, pcm.length);
});

test('long irregular-length input covers every sample once with bounded positive segments', () => {
  const pcm = new Float32Array(103 * SR + 1973);
  const plan = planPcmSegments(pcm);
  assertCoverage(plan, pcm.length);
  assert.equal(plan.length, 5);
});

test('planning leaves all original PCM bytes unchanged', () => {
  const pcm = tone(30 * SR);
  silenceWindow(pcm, 20 * SR);
  pcm[11] = -0;
  const before = new Uint8Array(pcm.buffer).slice();
  planPcmSegments(pcm);
  assert.deepEqual(new Uint8Array(pcm.buffer), before);
});

test('finite extreme Float32 values are accepted and produce finite RMS', () => {
  const pcm = new Float32Array(MAX + 1).fill(3.4028234663852886e38);
  const plan = planPcmSegments(pcm);
  assert(Number.isFinite(plan[0].rms));
  assertCoverage(plan, pcm.length);
});

test('NaN and positive or negative Infinity are rejected even outside candidate windows', () => {
  for (const value of [NaN, Infinity, -Infinity]) {
    for (const index of [0, MAX]) {
      const pcm = tone(MAX + 1);
      pcm[index] = value;
      assert.throws(() => planPcmSegments(pcm), /non-finite sample/);
    }
  }
});

test('every non-16 kHz rate is rejected; default and explicit 16 kHz agree', () => {
  const pcm = tone(3);
  for (const rate of [8000, 44100, 48000, 0, -16000, 16000.1, NaN, Infinity, '16000', null]) {
    assert.throws(() => planPcmSegments(pcm, rate), /exactly 16000/);
  }
  assert.deepEqual(planPcmSegments(pcm), planPcmSegments(pcm, SR));
});

test('empty or non-Float32Array input is rejected', () => {
  assert.throws(() => planPcmSegments(new Float32Array()), /at least one sample/);
  for (const pcm of [[], [0], new Float64Array(1), new Uint8Array(1), null, undefined]) {
    assert.throws(() => planPcmSegments(pcm), /Float32Array/);
  }
});
