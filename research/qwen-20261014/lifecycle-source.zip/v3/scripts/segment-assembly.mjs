import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { planPcmSegments } from './segment-plan.mjs';

export const shaBytes = bytes => createHash('sha256').update(bytes).digest('hex');

export function describeSegments(parent, raw) {
  assert(Buffer.isBuffer(raw) && raw.length > 0 && raw.length % 4 === 0);
  assert.equal(shaBytes(raw), parent.pcm_sha256, 'Original PCM changed');
  const pcm = new Float32Array(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength));
  assert.equal(pcm.length / 16000, parent.audio_seconds);
  const ranges = planPcmSegments(pcm, 16000);
  let covered = 0;
  const segments = ranges.map((range, index) => {
    assert.equal(range.start, covered); assert(range.end > range.start && range.end - range.start <= 24 * 16000);
    covered = range.end;
    return { id: `${parent.id}::segment-${String(index + 1).padStart(3, '0')}`,
      segment_index: index, ...range, sample_count: range.end - range.start,
      audio_seconds: (range.end - range.start) / 16000,
      pcm_sha256: shaBytes(raw.subarray(range.start * 4, range.end * 4)),
      parent_id: parent.id, parent_pcm_sha256: parent.pcm_sha256 };
  });
  assert.equal(covered, pcm.length);
  return segments;
}

export function assembleParentResult(parent, index, plan, segments) {
  assert(segments.length <= plan.length);
  for (let i = 0; i < segments.length; i++) {
    for (const key of ['id', 'start', 'end', 'pcm_sha256', 'parent_pcm_sha256']) assert.equal(segments[i][key], plan[i][key]);
    if (segments[i].status === 'complete') assert.equal(typeof segments[i].engine_output?.text, 'string');
  }
  const complete = segments.length === plan.length && segments.every(s => s.status === 'complete');
  const joinedText = segments.filter(s => s.status === 'complete').map(s => s.engine_output.text).join(' ');
  return { id: parent.id, index, status: complete ? 'complete' : 'failed',
    pcm_sha256: parent.pcm_sha256, language: parent.language, audio_seconds: parent.audio_seconds,
    expected_segments: plan.length, completed_segments: segments.filter(s => s.status === 'complete').length,
    input_coverage: { samples: parent.audio_seconds * 16000, first_sample: plan[0].start,
      last_sample_exclusive: plan.at(-1).end, full_contiguous_plan: true, overlap_samples: 0, dropped_samples: 0 },
    join_operation: 'Exact engine segment strings joined with one ASCII space; no trim, punctuation edits, deduplication or semantic repair.',
    ...(complete ? { text: joinedText, text_sha256: shaBytes(joinedText) }
      : { error: 'At least one segment failed or was not attempted. No complete-file transcription is claimed.',
        partial_text_diagnostic: joinedText, partial_text_diagnostic_sha256: shaBytes(joinedText) }),
    segments };
}
