// Pure sample-index planning only: no VAD, resampling, padding, or PCM changes.
const SAMPLE_RATE = 16_000;
const MAX_SAMPLES = 24 * SAMPLE_RATE;
const MIN_CUT_SAMPLES = 18 * SAMPLE_RATE;
const STEP_SAMPLES = SAMPLE_RATE / 10;
const HALF_WINDOW_SAMPLES = SAMPLE_RATE / 10;

/**
 * Plan contiguous, non-overlapping half-open ranges in the original PCM.
 * `start` is inclusive; `end` is exclusive; both are integer sample indices.
 *
 * Every non-final range ends at the lowest-power candidate between 18 and
 * 24 seconds after its start, inclusive, on a 100 ms grid. Each candidate is
 * measured over its original-audio 200 ms centered window, clipped only to
 * the audio bounds and normalized by the actual number of window samples.
 * Equal measured power selects the later candidate. A final range of any
 * positive length, including less than 2 seconds, is retained unchanged.
 *
 * @param {Float32Array} pcm Nonempty finite 16 kHz mono PCM samples.
 * @param {number} [sampleRate=16000] Only 16000 is accepted.
 * @returns {{start: number, end: number, rms?: number, reason: string}[]}
 */
export function planPcmSegments(pcm, sampleRate = SAMPLE_RATE) {
  if (!(pcm instanceof Float32Array)) {
    throw new TypeError('PCM must be a Float32Array');
  }
  if (sampleRate !== SAMPLE_RATE) {
    throw new RangeError('PCM sample rate must be exactly 16000 Hz');
  }
  if (pcm.length === 0) {
    throw new RangeError('PCM must contain at least one sample');
  }
  for (let i = 0; i < pcm.length; i++) {
    if (!Number.isFinite(pcm[i])) {
      throw new RangeError(`PCM contains a non-finite sample at index ${i}`);
    }
  }

  const segments = [];
  let start = 0;
  while (pcm.length - start > MAX_SAMPLES) {
    let bestEnd = -1;
    let bestPower = Infinity;
    for (let end = start + MIN_CUT_SAMPLES;
      end <= start + MAX_SAMPLES; end += STEP_SAMPLES) {
      const left = Math.max(0, end - HALF_WINDOW_SAMPLES);
      const right = Math.min(pcm.length, end + HALF_WINDOW_SAMPLES);
      let sumSquares = 0;
      let compensation = 0;
      // Compensated summation avoids losing small powers beside larger ones.
      // Squared finite Float32 samples cannot overflow a JavaScript Number.
      for (let i = left; i < right; i++) {
        const term = pcm[i] * pcm[i] - compensation;
        const next = sumSquares + term;
        compensation = (next - sumSquares) - term;
        sumSquares = next;
      }
      const power = sumSquares / (right - left);
      // Candidates are visited in increasing order, so <= resolves ties late.
      if (power <= bestPower) {
        bestPower = power;
        bestEnd = end;
      }
    }
    segments.push({ start, end: bestEnd, rms: Math.sqrt(bestPower), reason: 'minimum_window_rms' });
    start = bestEnd;
  }
  segments.push({ start, end: pcm.length, reason: 'final_remainder' });
  return segments;
}
