#!/usr/bin/env node
// Frozen-v3 post-inference verification. Never creates a Worker or reads audio.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { sha, scoreVerifiedSuite, PRIOR } from './score-worker-lifecycle.mjs';

export const V3_PROTOCOL_SHA='f2fa3b0aae1f3410c36cf8037a0edf597e49ff63719e7158524d1cd39d127db8';
export const ORIGINAL_INPUT_SHA='15449b4550419e877116eba84e47ac0458f3f0ee760dee1a8f3f5fc5bf9c4708';
const INPUT_KEYS=['audio_seconds','id','language','pcm_path','pcm_sha256','sample_rate','split'];
const FINAL_STATES=['complete','failed','cancelled','supervisor_failed'];
const JOIN='Exact engine segment strings joined with one ASCII space; no trim, punctuation edits, deduplication or semantic repair.';
const parseTime=x=>{const n=Date.parse(x);assert(Number.isFinite(n),'Missing/invalid final-run timestamp');return n;};
export function validateCoverage(parent,plan) {
 assert(Array.isArray(plan)&&plan.length>0);const samples=parent.audio_seconds*16000;assert(Number.isInteger(samples));
 let end=0;
 for(let index=0;index<plan.length;index++) {
  const s=plan[index];assert.equal(s.segment_index,index);assert.equal(s.id,`${parent.id}::segment-${String(index+1).padStart(3,'0')}`);
  assert.equal(s.parent_id,parent.id);assert.equal(s.parent_pcm_sha256,parent.pcm_sha256);
  assert(Number.isInteger(s.start)&&Number.isInteger(s.end));assert.equal(s.start,end,'PCM gap or overlap');
  assert(s.end>s.start&&s.end-s.start<=24*16000);assert.equal(s.sample_count,s.end-s.start);assert.equal(s.audio_seconds,s.sample_count/16000);
  assert(/^[a-f0-9]{64}$/.test(s.pcm_sha256));end=s.end;
 }
 assert.equal(end,samples,'Plan does not cover the complete original PCM');
 return {samples,first_sample:0,last_sample_exclusive:samples,full_contiguous_plan:true,overlap_samples:0,dropped_samples:0};
}

function validateSegment({segment:s,expected,one,lifecycle:life,report,reportSha,inputSha,prefix,summary,protocol,state}) {
 const problems=[];
 assert.equal(s.runner_report,`${prefix}/runner-report.json`);assert.equal(s.lifecycle_report,`${prefix}/lifecycle.json`);
 assert.deepEqual(one,{cases:[expected]});assert.equal(s.report_sha256,reportSha);
 assert.equal(s.exit_confirmed,life.exit_confirmed);assert.equal(s.worker_exit_code,life.worker_exit_code);
 assert.equal(s.runner_exit_code,life.terminal_message?.runner_exit_code??null);assert.equal(s.termination_reason,life.termination_reason);
 assert.equal(s.thread_id,life.thread_id);assert(Number.isInteger(life.thread_id)&&life.thread_id>0);
 assert(!state.threadIds.has(life.thread_id),'A Worker thread was reused');state.threadIds.add(life.thread_id);
 assert(state.previousExitConfirmed,'A segment started before the preceding Worker exit was confirmed');
 const started=parseTime(life.started_at),ended=life.exit_confirmed?parseTime(life.worker_exited_at):null;
 assert(started>=state.batchStart&&started<=state.batchEnd);
 if(state.previousExit!=null)assert(started>=state.previousExit,'Overlapping Worker lifetimes or substituted prior diagnostic');
 if(ended!=null)assert(ended>=started&&ended<=state.batchEnd);
 state.previousExit=ended;state.previousExitConfirmed=life.exit_confirmed===true;
 const terminal=life.terminal_message;
 if(!life.exit_confirmed)problems.push('worker_exit_unconfirmed');
 if(life.status!=='worker_exited')problems.push('lifecycle_not_exited');
 if(life.termination_reason!=='runner_finalized'||terminal?.type!=='runner_finalized')problems.push('not_finalized_then_terminated');
 if(terminal?.runner_exit_code!==0)problems.push('runner_exit_not_zero');
 if(![0,1].includes(life.worker_exit_code))problems.push('unexpected_worker_exit');
 if(life.terminate_promise_exit_code!==life.worker_exit_code)problems.push('termination_promise_mismatch');
 if(!life.termination_requested_at)problems.push('termination_request_missing');
 else {const at=parseTime(life.termination_requested_at);assert(at>=started&&(ended==null||at<=ended));}
 if(terminal?.thread_id!==life.thread_id)problems.push('terminal_thread_mismatch');
 if(terminal?.report_sha256!==reportSha)problems.push('terminal_report_sha_mismatch');
 for(const key of ['worker_error','supervisor_error','persistence_error','monitor_error','log_write_error','terminate_error','duplicate_terminal_message','unknown_worker_message'])if(life[key])problems.push(key);
 if(report) {
  assert.equal(report.source_sha256,protocol.original_runner_sha256);assert.equal(report.input_manifest_sha256,inputSha);
  assert.deepEqual(report.settings,protocol.settings);assert.deepEqual(report.model,summary.model);assert.deepEqual(report.runtime,summary.runtime);
  const created=parseTime(report.created_at);assert(created>=started&&(ended==null||created<=ended),'Report was created outside this Worker; diagnostic output cannot be reused');
  assert.equal(s.runner_status,report.status);assert.equal(s.runner_stage,report.stage);
  if(report.status!=='complete'||report.stage!=='complete')problems.push('runner_report_incomplete');
  if(terminal?.status!==report.status)problems.push('terminal_status_conflict');
  if(report.cleanup_error||terminal?.cleanup_error||s.cleanup_error)problems.push('cleanup_error');
  if(!Array.isArray(report.network_attempts)||report.network_attempts.length)problems.push('network_isolation_failed');
  if(report.cases?.length!==1)problems.push('wrong_case_count');
  if(report.cases?.length===1) {
   const r=report.cases[0];assert.deepEqual(s.engine_output,r,'Parent segment output differs from its original runner artifact');
   assert.equal(r.id,expected.id);assert.equal(r.pcm_sha256,expected.pcm_sha256);assert.equal(r.language,expected.language);assert.equal(r.pass,1);
   assert(Math.abs(r.audio_seconds-expected.audio_seconds)<=1/16000);
   if(r.status!=='complete'||typeof r.text!=='string'||r.result?.text!==r.text)problems.push('invalid_engine_text');
   if(state.actualRuntime==null)state.actualRuntime=report.actual_runtime;else assert.deepEqual(report.actual_runtime,state.actualRuntime);
  }
 } else problems.push('runner_report_missing');
 const complete=problems.length===0&&s.status==='complete';
 if(s.status==='complete')assert(complete,`Segment claimed success without complete evidence: ${s.id} ${problems.join(',')}`);
 else assert.equal(s.status,'failed');
 return {complete,problems,engine:report?.cases?.[0]??null};
}

export function validateSegmentedLifecycle(bundle,{parentExitCode}={}) {
 const {summary:s,protocol:p,input,parentBundles}=bundle;
 assert(Number.isInteger(parentExitCode),'Observed parent exit is required');assert(FINAL_STATES.includes(s.status),'Wait for final summary');
 assert.equal(s.suite,'all31','longest1/diagnostic3 cannot be scored or merged as all31');
 assert.equal(bundle.protocolSha,V3_PROTOCOL_SHA);assert.equal(s.protocol_sha256,bundle.protocolSha);
 assert.equal(bundle.inputSha,ORIGINAL_INPUT_SHA);assert.equal(s.input_manifest_sha256,bundle.inputSha);assert.equal(s.original_input_manifest_sha256,bundle.inputSha);
 assert.equal(p.original_input_manifest_sha256,bundle.inputSha);assert.deepEqual(s.settings,p.settings);assert.deepEqual(s.code_files,p.code_files);
 assert.equal(p.planned_parent_files,31);assert.equal(p.planned_segments,48);assert.deepEqual(Object.keys(input),['cases']);assert.equal(input.cases.length,31);
 assert.equal(new Set(input.cases.map(c=>c.id)).size,31);assert.equal(p.cases_in_frozen_order.length,31);
 assert.deepEqual(Object.keys(p.segment_plans),input.cases.map(c=>c.id),'Frozen segment plans must follow original parent order');
 const coverages=new Map();let segmentCount=0;
 input.cases.forEach((c,i)=>{
  assert.deepEqual(Object.keys(c).sort(),INPUT_KEYS);assert.equal(c.sample_rate,16000);assert(path.isAbsolute(c.pcm_path));
  for(const key of INPUT_KEYS.filter(k=>k!=='pcm_path'))assert.equal(c[key],p.cases_in_frozen_order[i][key]);
  coverages.set(c.id,validateCoverage(c,p.segment_plans[c.id]));segmentCount+=p.segment_plans[c.id].length;
 });assert.equal(segmentCount,48);
 assert.deepEqual(s.planned_cases,input.cases.map(c=>({id:c.id,pcm_sha256:c.pcm_sha256})));
 assert.equal(s.assembly_provenance?.same_fixed_recordings,true);assert.equal(s.assembly_provenance?.independent_of_native_outputs,true);
 assert.equal(s.assembly_provenance?.operation,'Join exact segment engine text with one ASCII space in offset order; no other text edits.');
 assert(s.cases.length<=31);assert.equal(parentBundles.length,s.cases.length);
 assert.equal(s.completed_cases,s.cases.filter(c=>c.status==='complete').length);assert.equal(s.failed_cases,s.cases.filter(c=>c.status==='failed').length);assert.equal(s.unfinished_cases,31-s.cases.length);
 const state={batchStart:parseTime(s.created_at),batchEnd:parseTime(s.finished_at),previousExit:null,previousExitConfirmed:true,threadIds:new Set(),actualRuntime:null};
 assert(state.batchEnd>=state.batchStart);assert(parseTime(p.frozen_at)<=state.batchStart);
 const successful=s.status==='complete';assert.equal(successful,parentExitCode===0,'Parent exit and terminal status conflict');
 if(successful){assert.equal(s.cases.length,31);assert.equal(s.active_case,null);assert.equal(s.active_segment,null);assert(!s.active_worker_failure);}
 const validated=[];let confirmedExits=0;
 for(let index=0;index<s.cases.length;index++) {
  const row=s.cases[index],parent=input.cases[index],plan=p.segment_plans[parent.id],b=parentBundles[index],prefix=String(index+1).padStart(2,'0');
  assert.equal(row.id,parent.id);assert.equal(row.index,index);assert.equal(row.pcm_sha256,parent.pcm_sha256);assert.equal(row.language,parent.language);assert.equal(row.audio_seconds,parent.audio_seconds);
  assert.equal(row.expected_segments,plan.length);assert(row.segments.length<=plan.length);assert.equal(b.segments.length,row.segments.length);
  assert.deepEqual(row.input_coverage,coverages.get(parent.id));assert.equal(row.join_operation,JOIN);
  assert.deepEqual(b.segmentation,{parent,segments:plan});
  const withoutSource={...row};delete withoutSource.source_inference;assert.deepEqual(withoutSource,b.assembly,'Parent artifact differs from summary');
  assert.equal(row.source_inference?.source_result_path,`${prefix}/parent-assembly.json`);
  assert.equal(row.source_inference?.source_result_sha256,b.assemblySha);
  assert.deepEqual(row.source_inference?.segment_report_sha256s,row.segments.map(t=>t.report_sha256));
  const checked=[],segmentPublic=[];
  for(let j=0;j<row.segments.length;j++) {
   const segment=row.segments[j],sb=b.segments[j],segmentPrefix=`${prefix}/${String(j+1).padStart(2,'0')}`;
   for(const [key,value]of Object.entries(plan[j]))assert.deepEqual(segment[key],value,`Frozen segment differs: ${parent.id} ${j} ${key}`);
   const expected={...parent,id:plan[j].id,pcm_path:sb.expectedPcmPath,pcm_sha256:plan[j].pcm_sha256,audio_seconds:plan[j].audio_seconds};
   assert(path.isAbsolute(expected.pcm_path));assert(expected.pcm_path.endsWith(`/${segmentPrefix}/audio.f32`));
   const result=validateSegment({segment,expected,one:sb.input,lifecycle:sb.lifecycle,report:sb.report,reportSha:sb.reportSha,inputSha:sb.inputSha,prefix:segmentPrefix,summary:s,protocol:p,state});
   checked.push(result);if(sb.lifecycle.exit_confirmed)confirmedExits++;
   segmentPublic.push({id:segment.id,segment_index:j,start_sample:segment.start,end_sample_exclusive:segment.end,sample_count:segment.sample_count,
    audio_seconds:segment.audio_seconds,pcm_sha256:segment.pcm_sha256,status:result.complete?'complete':'failed',problems:result.problems,
    runner_report:segment.runner_report,report_sha256:sb.reportSha,input_sha256:sb.inputSha,lifecycle_sha256:sb.lifecycleSha,
    actual_text_sha256:typeof result.engine?.text==='string'?sha(result.engine.text):null,thread_id:sb.lifecycle.thread_id,
    runner_exit_code:sb.lifecycle.terminal_message?.runner_exit_code??null,worker_exit_code:sb.lifecycle.worker_exit_code,
    terminate_promise_exit_code:sb.lifecycle.terminate_promise_exit_code??null,exit_confirmed:sb.lifecycle.exit_confirmed,
    decode_seconds:result.engine?.decode_seconds??null,memory_after_decode:result.engine?.memory_after_decode??null,
    resource_after_worker_exit:sb.lifecycle.resource_after_worker_exit??null,
    returned_token_count:Array.isArray(result.engine?.result?.tokens)?result.engine.result.tokens.length:null,truncated:null});
  }
  const complete=checked.length===plan.length&&checked.every(t=>t.complete);
  assert.equal(row.completed_segments,checked.filter(t=>t.complete).length);
  assert.equal(row.status,complete?'complete':'failed','All segments must succeed before the parent can succeed');
  const joined=checked.filter(t=>t.complete).map(t=>t.engine.text).join(' ');
  if(complete){assert.equal(row.text,joined,'Only exact ASCII-space concatenation is permitted');assert.equal(row.text_sha256,sha(joined));assert(!('partial_text_diagnostic'in row));}
  else {assert(!('text'in row)&&!('text_sha256'in row),'Failed parent must not claim a complete transcript');assert.equal(row.partial_text_diagnostic,joined);assert.equal(row.partial_text_diagnostic_sha256,sha(joined));}
  validated.push({id:parent.id,status:complete?'complete':'failed',problems:complete?[]:['one_or_more_segments_failed_or_missing'],engine:complete?{text:joined}:null,
   report_sha256:b.assemblySha,input_sha256:bundle.inputSha,lifecycle_sha256:null,thread_id:null,runner_exit_code:complete?0:null,
   worker_exit_code:null,terminate_promise_exit_code:null,exit_confirmed:checked.length===plan.length&&segmentPublic.every(t=>t.exit_confirmed),
   coverage:coverages.get(parent.id),expected_segments:plan.length,complete_segments:checked.filter(t=>t.complete).length,segment_public:segmentPublic});
 }
 assert(!successful||validated.length===31&&validated.every(c=>c.status==='complete'));
 return {scheme_id:'web_wasm_segment_workers',worker_unit:'segment',expected_workers:48,confirmed_worker_exits:confirmedExits,
  successful,validated,actual_runtime:state.actualRuntime,expected_cases:31,completed_cases:validated.filter(c=>c.status==='complete').length,parent_exit_code:parentExitCode};
}

async function readJson(filename){const bytes=await fs.readFile(filename);return {value:JSON.parse(bytes),sha256:sha(bytes)};}
async function confined(root,relative,optional=false){
 assert(!path.isAbsolute(relative)&&!relative.split('/').includes('..'));
 const filename=path.join(root,relative);
 try{assert((await fs.realpath(filename)).startsWith((await fs.realpath(root))+path.sep),'File escapes this all31 run');return await readJson(filename);}
 catch(error){if(optional&&error.code==='ENOENT')return null;throw error;}
}
export async function loadVerifiedSegmentedSuite(summaryPath,protocolPath,inputPath,parentExitCode){
 const summary=await readJson(summaryPath);assert(FINAL_STATES.includes(summary.value.status),'Do not read a running checkpoint');assert.equal(summary.value.suite,'all31');
 const [protocol,input,plans]=await Promise.all([readJson(protocolPath),readJson(inputPath),readJson(path.join(path.dirname(protocolPath),'segmentation-plans-frozen.json'))]);
 assert.equal(protocol.sha256,V3_PROTOCOL_SHA);assert.equal(plans.sha256,protocol.value.segment_plans_sha256);
 for(const item of protocol.value.code_files){assert(!path.isAbsolute(item.path)&&!item.path.split('/').includes('..'));assert.equal(sha(await fs.readFile(path.join(path.dirname(protocolPath),item.path))),item.sha256,`Frozen source changed: ${item.path}`);}
 const root=path.dirname(summaryPath),parentBundles=[];
 for(let i=0;i<summary.value.cases.length;i++){
  const prefix=String(i+1).padStart(2,'0'),row=summary.value.cases[i];
  const [assembly,segmentation]=await Promise.all([confined(root,`${prefix}/parent-assembly.json`),confined(root,`${prefix}/segmentation.json`)]);
  const segments=[];
  for(let j=0;j<row.segments.length;j++){
   const sp=`${prefix}/${String(j+1).padStart(2,'0')}`;
   const [one,report,life]=await Promise.all([confined(root,`${sp}/input.json`),confined(root,`${sp}/runner-report.json`,true),confined(root,`${sp}/lifecycle.json`)]);
   segments.push({input:one.value,inputSha:one.sha256,report:report?.value??null,reportSha:report?.sha256??null,lifecycle:life.value,lifecycleSha:life.sha256,expectedPcmPath:path.join(root,sp,'audio.f32')});
  }
  parentBundles.push({assembly:assembly.value,assemblySha:assembly.sha256,segmentation:segmentation.value,segments});
 }
 const bundle={summary:summary.value,summarySha:summary.sha256,protocol:protocol.value,protocolSha:protocol.sha256,input:input.value,inputSha:input.sha256,parentBundles};
 return {bundle,validation:validateSegmentedLifecycle(bundle,{parentExitCode})};
}
async function main(){
 const a={};for(let i=2;i<process.argv.length;i+=2){assert(['--summary','--protocol','--input','--runner-exit-code','--output'].includes(process.argv[i]));assert(process.argv[i+1]);assert(!(process.argv[i]in a));a[process.argv[i]]=process.argv[i+1];}
 for(const key of ['--summary','--protocol','--runner-exit-code','--output'])assert(a[key],`Required ${key}`);
 const summaryPath=path.resolve(a['--summary']),protocolPath=path.resolve(a['--protocol']);
 const inputPath=path.resolve(a['--input']??path.join(PRIOR,'data/all-inference.json'));
 const {bundle,validation}=await loadVerifiedSegmentedSuite(summaryPath,protocolPath,inputPath,Number(a['--runner-exit-code']));
 await scoreVerifiedSuite({bundle,validation,summaryPath,protocolPath,outputPath:path.resolve(a['--output'])});
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url)main().catch(error=>{console.error('Segmented lifecycle scoring refused:',error.message);process.exitCode=1;});
