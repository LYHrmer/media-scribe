import test from 'node:test';
import assert from 'node:assert/strict';
import { sha, repeatedMeliInput, repeatedMeliReferences, privacyCheck } from './score-worker-lifecycle.mjs';
import { validateSegmentedLifecycle, V3_PROTOCOL_SHA, ORIGINAL_INPUT_SHA } from './score-segment-worker-lifecycle.mjs';
import { scoreRun } from './vendor/score-next-accuracy.mjs';

// Entirely synthetic metadata. The pure validator receives mocked outer hashes;
// the filesystem loader separately verifies real byte hashes before calling it.
// No real PCM, inference output, reference, model, protocol file or WASM is read.
const originalInput={cases:Array.from({length:31},(_,i)=>({id:`synthetic-case-${i}`,language:i%2?'english':'chinese',
 pcm_path:`/synthetic/source-${i}.f32`,pcm_sha256:sha(`synthetic-parent-${i}`),sample_rate:16000,audio_seconds:i<17?30:12,
 split:i>=23?'holdout':'development'}))};
const originalProtocol={frozen_at:'2026-10-14T00:00:00.000Z',original_input_manifest_sha256:ORIGINAL_INPUT_SHA,
 original_runner_sha256:sha('synthetic-frozen-runner'),planned_parent_files:31,planned_segments:48,code_files:[],
 settings:{sample_rate:16000,max_total_len:1280,max_new_tokens:512,repeat:1},
 cases_in_frozen_order:originalInput.cases.map(({pcm_path,...c})=>c),segment_plans:{}};
originalInput.cases.forEach((c,i)=>{const offsets=i<17?[[0,320000],[320000,480000]]:[[0,192000]];
 originalProtocol.segment_plans[c.id]=offsets.map(([start,end],index)=>({id:`${c.id}::segment-${String(index+1).padStart(3,'0')}`,
  segment_index:index,start,end,reason:'synthetic_test_boundary',sample_count:end-start,audio_seconds:(end-start)/16000,
  pcm_sha256:sha(`synthetic-segment-${i}-${index}`),parent_id:c.id,parent_pcm_sha256:c.pcm_sha256}));});
const clone=x=>structuredClone(x),digest=x=>sha(JSON.stringify(x));
const iso=x=>new Date(x).toISOString();
const JOIN='Exact engine segment strings joined with one ASCII space; no trim, punctuation edits, deduplication or semantic repair.';
function fixture(){
 const input=clone(originalInput),p=clone(originalProtocol),start=Date.parse(p.frozen_at)+10000;
 const s={status:'complete',suite:'all31',created_at:iso(start),finished_at:iso(start+200000),protocol_sha256:V3_PROTOCOL_SHA,
  input_manifest_sha256:ORIGINAL_INPUT_SHA,original_input_manifest_sha256:ORIGINAL_INPUT_SHA,code_files:clone(p.code_files),settings:clone(p.settings),
  model:{fixture:true},runtime:{version:'fixture'},active_case:null,active_segment:null,
  assembly_provenance:{same_fixed_recordings:true,independent_of_native_outputs:true,operation:'Join exact segment engine text with one ASCII space in offset order; no other text edits.'},
  planned_cases:input.cases.map(c=>({id:c.id,pcm_sha256:c.pcm_sha256})),cases:[],completed_cases:31,failed_cases:0,unfinished_cases:0};
 const parentBundles=[];let worker=0;
 input.cases.forEach((parent,i)=>{
  const plan=p.segment_plans[parent.id],prefix=String(i+1).padStart(2,'0'),segments=[],bundles=[];
  plan.forEach((part,j)=>{
   const thread=++worker,at=start+1000+thread*3000,sp=`${prefix}/${String(j+1).padStart(2,'0')}`,pcm=`/synthetic/all31/${sp}/audio.f32`;
   const expected={...parent,id:part.id,pcm_path:pcm,pcm_sha256:part.pcm_sha256,audio_seconds:part.audio_seconds};
   const one={cases:[expected]},text=` fixture-${thread} `;
   const engine={id:part.id,pass:1,status:'complete',pcm_sha256:part.pcm_sha256,language:parent.language,audio_seconds:part.audio_seconds,
    text,result:{text,tokens:['fixture']},decode_seconds:0.001,memory_after_decode:{wasm_heap_bytes:1,process:{rss:1}}};
   const report={status:'complete',stage:'complete',created_at:iso(at+300),source_sha256:p.original_runner_sha256,input_manifest_sha256:digest(one),
    settings:clone(p.settings),model:clone(s.model),runtime:clone(s.runtime),actual_runtime:{version:'fixture',git_sha1:'fixture'},network_attempts:[],cases:[clone(engine)]};
   const reportSha=digest(report),life={status:'worker_exited',started_at:iso(at),worker_exited_at:iso(at+2000),termination_requested_at:iso(at+1500),
    termination_reason:'runner_finalized',exit_confirmed:true,worker_exit_code:1,terminate_promise_exit_code:1,thread_id:thread,
    terminal_message:{type:'runner_finalized',status:'complete',runner_exit_code:0,report_sha256:reportSha,thread_id:thread},resource_after_worker_exit:{process:{rss:1}}};
   segments.push({...clone(part),status:'complete',reasons:[],worker_exit_code:1,runner_exit_code:0,termination_reason:'runner_finalized',thread_id:thread,exit_confirmed:true,
    report_sha256:reportSha,runner_report:`${sp}/runner-report.json`,lifecycle_report:`${sp}/lifecycle.json`,runner_status:'complete',runner_stage:'complete',cleanup_error:null,engine_output:clone(engine)});
   bundles.push({input:one,inputSha:digest(one),report,reportSha,lifecycle:life,lifecycleSha:digest(life),expectedPcmPath:pcm});
  });
  const text=segments.map(t=>t.engine_output.text).join(' '),samples=parent.audio_seconds*16000;
  const row={id:parent.id,index:i,status:'complete',pcm_sha256:parent.pcm_sha256,language:parent.language,audio_seconds:parent.audio_seconds,
   expected_segments:plan.length,completed_segments:plan.length,input_coverage:{samples,first_sample:0,last_sample_exclusive:samples,full_contiguous_plan:true,overlap_samples:0,dropped_samples:0},
   join_operation:JOIN,text,text_sha256:sha(text),segments};
  const assembly=clone(row);row.source_inference={source_result_path:`${prefix}/parent-assembly.json`,source_result_sha256:digest(assembly),segment_report_sha256s:segments.map(t=>t.report_sha256)};
  s.cases.push(row);parentBundles.push({assembly,assemblySha:digest(assembly),segmentation:{parent:clone(parent),segments:clone(plan)},segments:bundles});
 });
 assert.equal(worker,48);
 return {summary:s,summarySha:digest(s),protocol:p,protocolSha:V3_PROTOCOL_SHA,input,inputSha:ORIGINAL_INPUT_SHA,parentBundles};
}
function refreshParent(b,i){const row=b.summary.cases[i],bare=clone(row);delete bare.source_inference;b.parentBundles[i].assembly=bare;b.parentBundles[i].assemblySha=digest(bare);row.source_inference.source_result_sha256=digest(bare);row.source_inference.segment_report_sha256s=row.segments.map(s=>s.report_sha256);}
function refreshSegment(b,i,j,{copyEngine=true}={}){const sb=b.parentBundles[i].segments[j],s=b.summary.cases[i].segments[j];sb.reportSha=digest(sb.report);s.report_sha256=sb.reportSha;sb.lifecycle.terminal_message.report_sha256=sb.reportSha;if(copyEngine)s.engine_output=clone(sb.report.cases[0]);sb.lifecycleSha=digest(sb.lifecycle);refreshParent(b,i);}
function verify(b,code=0){return validateSegmentedLifecycle(b,{parentExitCode:code});}

test('all 31 parents / 48 segments accept runner zero plus explicitly terminated Worker one',()=>{const r=verify(fixture());assert.equal(r.completed_cases,31);assert.equal(r.confirmed_worker_exits,48);assert(r.successful);});
test('longest1 and diagnostic3 cannot masquerade as all31',()=>{for(const suite of ['longest1','diagnostic3']){const b=fixture();b.summary.suite=suite;assert.throws(()=>verify(b),/cannot be scored/);}});
test('running summary and mismatched parent exit are refused',()=>{const b=fixture();b.summary.status='running';assert.throws(()=>verify(b),/Wait for final/);assert.throws(()=>verify(fixture(),1),/exit and terminal/);});
test('frozen parent order cannot be changed',()=>{const b=fixture();[b.summary.cases[0],b.summary.cases[1]]=[b.summary.cases[1],b.summary.cases[0]];assert.throws(()=>verify(b));});
test('sample gap and overlap are rejected independently of claimed zero dropped samples',()=>{for(const delta of [-1,1]){const b=fixture(),id=b.input.cases.find(c=>b.protocol.segment_plans[c.id].length===2).id;b.protocol.segment_plans[id][1].start+=delta;assert.throws(()=>verify(b),/gap or overlap/);}});
test('segment SHA must match frozen plan and input artifact',()=>{const b=fixture();b.parentBundles[0].segments[0].input.cases[0].pcm_sha256='f'.repeat(64);assert.throws(()=>verify(b));});
test('runner artifact SHA must match lifecycle terminal and summary',()=>{const b=fixture();b.parentBundles[0].segments[0].lifecycle.terminal_message.report_sha256='f'.repeat(64);assert.throws(()=>verify(b),/terminal_report_sha_mismatch/);});
test('summary engine text cannot diverge from raw runner artifact',()=>{const b=fixture();b.summary.cases[0].segments[0].engine_output.text='tampered';refreshParent(b,0);assert.throws(()=>verify(b),/differs from its original runner/);});
test('report from earlier diagnostic time is rejected even with updated hashes',()=>{const b=fixture();b.parentBundles[0].segments[0].report.created_at=b.summary.created_at;refreshSegment(b,0,0);assert.throws(()=>verify(b),/outside this Worker/);});
test('runner nonzero is not excused by confirmed Worker exit',()=>{const b=fixture();const sb=b.parentBundles[0].segments[0];sb.lifecycle.terminal_message.runner_exit_code=1;b.summary.cases[0].segments[0].runner_exit_code=1;refreshParent(b,0);assert.throws(()=>verify(b),/runner_exit_not_zero/);});
test('Worker exit and termination promise must both be explicit',()=>{for(const field of ['exit_confirmed','terminate_promise_exit_code','termination_requested_at']){const b=fixture(),sb=b.parentBundles[0].segments[0];if(field==='exit_confirmed'){sb.lifecycle[field]=false;b.summary.cases[0].segments[0][field]=false;}else delete sb.lifecycle[field];refreshParent(b,0);assert.throws(()=>verify(b));}});
test('a Worker identity cannot be reused for the next segment',()=>{const b=fixture();const previous=b.summary.cases[0].segments[0].thread_id;const sb=b.parentBundles[1].segments[0],s=b.summary.cases[1].segments[0];sb.lifecycle.thread_id=previous;sb.lifecycle.terminal_message.thread_id=previous;s.thread_id=previous;refreshParent(b,1);assert.throws(()=>verify(b),/thread was reused/);});
test('case paths must remain in their precise batch and segment directory',()=>{const b=fixture();b.summary.cases[0].segments[0].runner_report='../longest1/01/01/runner-report.json';refreshParent(b,0);assert.throws(()=>verify(b));});
test('concatenation preserves leading/trailing spaces and inserts exactly one ASCII space',()=>{const b=fixture();const i=b.input.cases.findIndex(c=>b.protocol.segment_plans[c.id].length===2);assert(verify(b).successful);b.summary.cases[i].text=b.summary.cases[i].text.trim();b.summary.cases[i].text_sha256=sha(b.summary.cases[i].text);refreshParent(b,i);assert.throws(()=>verify(b),/ASCII-space concatenation/);});
test('missing segment cannot become complete-file transcription',()=>{const b=fixture();const i=b.input.cases.findIndex(c=>b.protocol.segment_plans[c.id].length===2);b.summary.cases[i].segments.pop();b.parentBundles[i].segments.pop();refreshParent(b,i);assert.throws(()=>verify(b));});
test('failed segment yields failed parent with no complete text and no full run success',()=>{
 const b=fixture(),s=b.summary.cases[0].segments[0],sb=b.parentBundles[0].segments[0],row=b.summary.cases[0];
 s.status='failed';s.runner_exit_code=1;sb.lifecycle.terminal_message.runner_exit_code=1;
 row.status='failed';row.completed_segments=row.segments.length-1;delete row.text;delete row.text_sha256;row.partial_text_diagnostic=row.segments.slice(1).map(t=>t.engine_output.text).join(' ');row.partial_text_diagnostic_sha256=sha(row.partial_text_diagnostic);
 b.summary.status='failed';b.summary.completed_cases=30;b.summary.failed_cases=1;refreshParent(b,0);
 const r=verify(b,1);assert.equal(r.completed_cases,30);assert.equal(r.successful,false);assert.equal(r.validated[0].engine,null);
});
test('former holdout is explicitly current development without changing source input or PCM',()=>{const source={cases:[{id:'example',split:'holdout',pcm_sha256:'a'.repeat(64)}]};const mapped=repeatedMeliInput(source);assert.equal(mapped.cases[0].split,'development');assert.equal(source.cases[0].split,'holdout');assert.equal(mapped.cases[0].pcm_sha256,source.cases[0].pcm_sha256);assert.equal(repeatedMeliReferences({cases:[{split:'holdout',reference:'fixture'}]}).cases[0].split,'development');});
test('canonical scorer keeps full-set metrics null for a failed batch despite completed output',()=>{
 const c={id:'meli-f01b-zh',language:'chinese',pcm_path:'/synthetic.f32',pcm_sha256:'a'.repeat(64),sample_rate:16000,audio_seconds:1,split:'development'};
 const r=scoreRun({cases:[c]},{cases:[{id:c.id,language:c.language,split:c.split,reference:'测试',reference_sha256:sha('测试')}]},{status:'failed',worker_returncode:1,cases:[{...c,status:'complete',text:'测试'}]},{format:'native',runnerExitCode:1});
 assert.equal(r.status,'incomplete');assert.equal(r.groups[0].weighted_rate,null);assert.equal(r.groups[0].completed_subset_only.errors,0);
});
test('public privacy guard rejects transcript/reference/tokens and absolute paths',()=>{for(const v of [{text:'private'},{reference:'private'},{tokens:[]},{name:'/workspace/private'}])assert.throws(()=>privacyCheck(v));privacyCheck({actual_text_sha256:'a'.repeat(64),reference_units:3});});
