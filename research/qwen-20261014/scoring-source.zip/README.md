# 独立事后评分源码

本包只验证和评分已经结束的推理，不加载模型、不创建 Worker、不读取媒体。实际媒体、参考文本、转写结果和日志均不在包内。`vendor/` 复用上一轮评分算法，仅把导入路径改为包内相对路径；原始和打包 SHA 见 `vendor/SOURCE_PROVENANCE.json`。

无模型自测（完全合成数据，不需要原实验文件）：

```sh
node --test score-segment-worker-lifecycle.test.mjs
```

v3 全批次结束后评分：

```sh
TINGXIE_PREVIOUS_EXPERIMENT_DIR=/path/to/previous-evidence \
node score-segment-worker-lifecycle.mjs \
  --summary /path/to/all31/summary.json \
  --protocol /path/to/v3/protocol-frozen.json \
  --runner-exit-code 0 \
  --output lifecycle-v3-public-results.json
```

`--runner-exit-code` 必须使用父进程实际观察到的退出码，失败时填写实际非零值。显式 `Worker.terminate()` 常返回线程退出码 1；它必须与原 runner 退出码 0、终止请求及退出记录分别核验。`score-worker-lifecycle.mjs` 也是公共辅助模块，其命令行入口仅供先前整文件协议使用。

需要自行保留 v3 冻结协议、其完整源码布局和分段规划文件，以及本次 `all31` 中的原始 `summary.json`、各父 `parent-assembly.json` / `segmentation.json`、各段 `input.json` / `runner-report.json` / `lifecycle.json`。既有证据目录沿用上一轮 `data/` 文件命名，包含推理清单、评分专用本地参考、实际默认基线、native 基线和上一轮公开汇总；不应把本地参考放进模型输入或公开仓库。

适配器核验固定 31 父录音、48 段的顺序、PCM 哈希、样本偏移连续覆盖、各报告哈希、独立 Worker 生命周期及精确的单个 ASCII 空格拼接。它不从 `longest1` / `diagnostic3` 补齐结果，不逐例挑选其他配置。父录音只有全部段成功才有完整文本。公开输出只含数字、哈希和来源元数据。

主指标保持既有中文 CER / 英文 WER 正规化；S/D/I 与原评分距离核对，数字等价 CER 仅作次指标。八个前轮 holdout 在本轮统一标记为 development 重复验证；没有新增独立留出集。缺失或失败批次没有完整组准确率；Sherpa 的真实生成截断状态保持未知。

`SOURCE_MANIFEST.json` 在实际结果评分前冻结。执行评分时会核验清单中每份源码，修改任何文件都必须创建新的明确版本，不能悄悄改变已冻结评分器。
