#!/usr/bin/env node
// Independent post-inference adapter. No inference, Worker creation, or media reads.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { scoreRun, summarize } from './vendor/score-next-accuracy.mjs';
import { scoreControls } from './vendor/score-controls-only.mjs';

export const PRIOR=path.resolve(process.env.TINGXIE_PREVIOUS_EXPERIMENT_DIR??'/workspace/experiments/next-accuracy-oct14');
export const sha=value=>createHash('sha256').update(value).digest('hex');
const KEYS=['audio_seconds','id','language','pcm_path','pcm_sha256','sample_rate','split'];
const terminalStates=['complete','failed','cancelled','supervisor_failed'];
const pins=[
 [fileURLToPath(new URL('./vendor/score-transcripts.mjs',import.meta.url)),'3354f77301683386381df60cf898a69d59a51d266bad11eb7718dbf791f3f731'],
 [fileURLToPath(new URL('./vendor/score-next-accuracy.mjs',import.meta.url)),'801030682b0897b0f762674870e8cfa06dcde11efa0b248e0f97f4180faba94b'],
 [fileURLToPath(new URL('./vendor/score-controls-only.mjs',import.meta.url)),'9c327f82965a0b40677f095e68975f0bda6adecc9940851d14f75759c51834ea'],
];
const time=value=>{ const n=Date.parse(value);assert(Number.isFinite(n),'Required timestamp missing or invalid');return n; };
export const repeatedMeliInput=input=>({cases:input.cases.map(c=>({...c,split:'development'}))});
export const repeatedMeliReferences=refs=>({...refs,cases:refs.cases.map(c=>({...c,split:'development'}))});

export function validateLifecycle(bundle,{parentExitCode}={}) {
 const {summary:s,protocol:p,input,caseBundles}=bundle;
 assert(Number.isInteger(parentExitCode),'Observed parent CLI exit code is required');
 assert(terminalStates.includes(s.status),'Wait for terminal summary, never score a running checkpoint');
 assert.equal(s.suite,'all31','diagnostic3 must never be pooled or substituted into all31');
 assert.equal(s.protocol_sha256,bundle.protocolSha);assert.equal(s.original_input_manifest_sha256,bundle.inputSha);
 assert.equal(p.original_input_manifest_sha256,bundle.inputSha);assert.equal(bundle.inputSha,'15449b4550419e877116eba84e47ac0458f3f0ee760dee1a8f3f5fc5bf9c4708');
 assert.deepEqual(s.settings,p.settings);assert.deepEqual(s.code_files,p.code_files);
 assert.equal(input.cases.length,31);assert.deepEqual(Object.keys(input),['cases']);
 assert.equal(p.cases_in_frozen_order.length,31);assert.equal(new Set(input.cases.map(c=>c.id)).size,31);
 input.cases.forEach((c,i)=>{
  assert.deepEqual(Object.keys(c).sort(),KEYS);assert(path.isAbsolute(c.pcm_path));assert.equal(c.sample_rate,16000);
  assert(/^[a-f0-9]{64}$/.test(c.pcm_sha256));
  for(const key of KEYS.filter(k=>k!=='pcm_path'))assert.equal(c[key],p.cases_in_frozen_order[i][key],`Frozen case mismatch ${i} ${key}`);
 });
 assert.deepEqual(s.planned_cases,input.cases.map(c=>({id:c.id,pcm_sha256:c.pcm_sha256})));
 assert.equal(caseBundles.length,s.cases.length);assert(s.cases.length<=31);
 assert.equal(s.completed_cases,s.cases.filter(c=>c.status==='complete').length);
 assert.equal(s.failed_cases,s.cases.filter(c=>c.status==='failed').length);
 assert.equal(s.unfinished_cases,31-s.cases.length);
 const batchStart=time(s.created_at),batchEnd=time(s.finished_at);assert(batchEnd>=batchStart);
 assert(time(p.frozen_at)<=batchStart,'Protocol must predate the run');
 const successful=s.status==='complete';assert.equal(successful,parentExitCode===0,'Parent status and observed exit conflict');
 if(successful){assert.equal(s.cases.length,31);assert.equal(s.active_case,null);assert.equal(s.completed_cases,31);assert(!s.active_worker_failure);}
 const threadIds=new Set(),validated=[];let lastExit=null,lastExitConfirmed=true,actualRuntime=null;
 for(let index=0;index<s.cases.length;index++) {
  const row=s.cases[index],c=input.cases[index],b=caseBundles[index],life=b.lifecycle,report=b.report;
  assert.equal(row.index,index);assert.equal(row.id,c.id);assert.equal(row.pcm_sha256,c.pcm_sha256);assert.equal(row.language,c.language);assert.equal(row.audio_seconds,c.audio_seconds);
  const prefix=String(index+1).padStart(2,'0');
  assert.equal(row.runner_report,`${prefix}/runner-report.json`,'Case report must belong to its own all31 directory');
  assert.equal(row.lifecycle_report,`${prefix}/lifecycle.json`);
  assert.deepEqual(b.input,{cases:[c]});assert.equal(row.report_sha256,b.reportSha);
  assert.equal(row.exit_confirmed,life.exit_confirmed);assert.equal(row.worker_exit_code,life.worker_exit_code);
  assert.equal(row.runner_exit_code,life.terminal_message?.runner_exit_code??null);
  assert.equal(row.termination_reason,life.termination_reason);assert.equal(row.thread_id,life.thread_id);
  assert(Number.isInteger(life.thread_id)&&life.thread_id>0);assert(!threadIds.has(life.thread_id),'Worker identity reused');threadIds.add(life.thread_id);
  const start=time(life.started_at);assert(start>=batchStart&&start<=batchEnd);
  assert(lastExitConfirmed,'Another Worker started before the preceding exit was confirmed');
  if(lastExit!=null)assert(start>=lastExit,'Workers overlap or a prior diagnostic lifecycle was substituted');
  const end=life.exit_confirmed?time(life.worker_exited_at):null;
  if(end!=null)assert(end>=start&&end<=batchEnd);
  lastExit=end;lastExitConfirmed=life.exit_confirmed===true;
  const problems=[];
  if(!life.exit_confirmed)problems.push('worker_exit_unconfirmed');
  if(life.status!=='worker_exited')problems.push('lifecycle_not_exited');
  if(life.termination_reason!=='runner_finalized')problems.push('not_terminated_after_runner_finalized');
  const terminal=life.terminal_message;
  if(terminal?.type!=='runner_finalized'||terminal.runner_exit_code!==0)problems.push('runner_not_successfully_finalized');
  if(![0,1].includes(life.worker_exit_code))problems.push('unexpected_worker_exit_code');
  if(life.terminate_promise_exit_code!==life.worker_exit_code)problems.push('termination_promise_exit_not_confirmed');
  if(!life.termination_requested_at)problems.push('termination_request_missing');
  else {const request=time(life.termination_requested_at);assert(request>=start&&(end==null||request<=end));}
  for(const key of ['worker_error','supervisor_error','monitor_error','log_write_error','terminate_error','duplicate_terminal_message','unknown_worker_message'])if(life[key])problems.push(key);
  if(terminal&&terminal.thread_id!==life.thread_id)problems.push('terminal_thread_mismatch');
  if(terminal?.report_sha256!==b.reportSha)problems.push('terminal_report_sha_mismatch');
  if(report) {
   assert.equal(report.source_sha256,p.original_runner_sha256);assert.equal(report.input_manifest_sha256,b.inputSha);
   assert.deepEqual(report.settings,p.settings);assert.deepEqual(report.model,s.model);assert.deepEqual(report.runtime,s.runtime);
   const created=time(report.created_at);assert(created>=start&&(end==null||created<=end),'Report was not created during this Worker; possible cross-suite substitution');
   assert.equal(row.runner_status,report.status);assert.equal(row.runner_stage,report.stage);
   if(report.status!=='complete'||report.stage!=='complete')problems.push('runner_report_incomplete');
   if(report.cleanup_error||terminal?.cleanup_error||row.cleanup_error)problems.push('cleanup_error');
   if(terminal?.status!==report.status)problems.push('terminal_report_status_conflict');
   if(!Array.isArray(report.network_attempts)||report.network_attempts.length)problems.push('network_isolation_failed');
   if(report.cases?.length!==1)problems.push('single_case_count_invalid');
   if(report.cases?.length===1) {
    const engine=report.cases[0];assert.deepEqual(row.engine_output,engine,'Summary engine output differs from original runner report');
    assert.equal(engine.id,c.id);assert.equal(engine.pcm_sha256,c.pcm_sha256);assert.equal(engine.language,c.language);
    assert(Math.abs(engine.audio_seconds-c.audio_seconds)<=1/16000);assert.equal(engine.pass,1);
    if(engine.status!=='complete'||typeof engine.text!=='string')problems.push('engine_result_not_complete');
    if(engine.result?.text!==engine.text)problems.push('engine_text_alias_conflict');
    if(actualRuntime==null)actualRuntime=report.actual_runtime;else assert.deepEqual(report.actual_runtime,actualRuntime);
   }
  } else problems.push('missing_runner_report');
  const valid=problems.length===0;
  if(row.status==='complete')assert(valid,`Claimed success conflicts with independent evidence: ${c.id}: ${problems.join(',')}`);
  else assert.equal(row.status,'failed');
  validated.push({id:c.id,status:valid&&row.status==='complete'?'complete':'failed',problems,engine:report?.cases?.[0]??null,
   report_sha256:b.reportSha,input_sha256:b.inputSha,lifecycle_sha256:b.lifecycleSha,
   thread_id:life.thread_id,runner_exit_code:terminal?.runner_exit_code??null,worker_exit_code:life.worker_exit_code,
   terminate_promise_exit_code:life.terminate_promise_exit_code??null,exit_confirmed:life.exit_confirmed,
   resource_after_worker_exit:life.resource_after_worker_exit??null});
 }
 assert(!successful||validated.length===31&&validated.every(c=>c.status==='complete'));
 return {successful,validated,actual_runtime:actualRuntime,expected_cases:31,completed_cases:validated.filter(c=>c.status==='complete').length,parent_exit_code:parentExitCode};
}

async function jsonFile(filename){const bytes=await fs.readFile(filename);return {bytes,value:JSON.parse(bytes),sha256:sha(bytes)};}
async function confinedFile(root,relative,{optional=false}={}) {
 assert(!path.isAbsolute(relative)&&!relative.split('/').includes('..'));
 const filename=path.join(root,relative);
 try {assert((await fs.realpath(filename)).startsWith((await fs.realpath(root))+path.sep),'Source escapes this all31 batch');return await jsonFile(filename);}
 catch(error){if(optional&&error.code==='ENOENT')return null;throw error;}
}
export async function loadVerifiedSuite(summaryPath,protocolPath,inputPath,parentExitCode) {
 const summary=await jsonFile(summaryPath);assert(terminalStates.includes(summary.value.status),'Do not read incomplete batch outputs');
 const [protocol,input]=await Promise.all([jsonFile(protocolPath),jsonFile(inputPath)]);
 assert.equal(summary.value.suite,'all31');
 for(const item of protocol.value.code_files){const file=await fs.readFile(path.resolve(path.dirname(protocolPath),item.path));assert.equal(sha(file),item.sha256,`Frozen code changed: ${item.path}`);}
 const root=path.dirname(summaryPath),caseBundles=[];
 for(let i=0;i<summary.value.cases.length;i++) {
  const prefix=String(i+1).padStart(2,'0');
  const [one,report,life]=await Promise.all([confinedFile(root,`${prefix}/input.json`),confinedFile(root,`${prefix}/runner-report.json`,{optional:true}),confinedFile(root,`${prefix}/lifecycle.json`)]);
  caseBundles.push({input:one.value,inputSha:one.sha256,report:report?.value??null,reportSha:report?.sha256??null,lifecycle:life.value,lifecycleSha:life.sha256});
 }
 const bundle={summary:summary.value,summarySha:summary.sha256,protocol:protocol.value,protocolSha:protocol.sha256,input:input.value,inputSha:input.sha256,caseBundles};
 return {bundle,validation:validateLifecycle(bundle,{parentExitCode})};
}

function publicMetric(s){if(s==null)return null;return Object.fromEntries(Object.entries(s).map(([k,v])=>[k==='reference_tokens'?'reference_units':k==='hypothesis_tokens'?'hypothesis_units':k,v]));}
function sourceRows(source,ids){return source.cases.filter(r=>ids.has(r.id)).map(r=>{const out={...r};delete out.split;return out;});}
function assertScoreEqual(current,prior){for(const key of ['metric','errors','substitutions','deletions','insertions','rate'])assert.equal(current?.[key],prior?.[key]);if(current)assert.equal(current.reference_tokens,prior.reference_units);}
function publicMeli(scored,oldInputs,complete) {
 const oldBy=new Map(oldInputs.cases.map(c=>[c.id,c]));
 const cases=scored.cases.map(c=>({id:c.id,participant_id:c.participant_id,split:'development',validation_role:'repeated_development',
  previous_round_split:oldBy.get(c.id).split,cohort:oldBy.get(c.id).split==='holdout'?'previous_round_eight':'prior_fifteen',
  language:c.language,status:c.status,pcm_sha256:c.pcm_sha256,reference_sha256:c.reference_sha256,
  actual_text_sha256:c.status==='complete'?sha(c.text):null,primary:publicMetric(c.score),truncated:null}));
 const groups=[];
 for(const cohort of ['all_repeated','prior_fifteen','previous_round_eight'])for(const language of ['chinese','english']) {
  const selected=scored.cases.filter(c=>c.language===language&&(cohort==='all_repeated'||(oldBy.get(c.id).split==='holdout'?'previous_round_eight':'prior_fifteen')===cohort));
  const g=summarize(selected,complete);groups.push({split:'development',validation_role:'repeated_development',cohort,language,metric:language==='chinese'?'CER':'WER',...g,
   full_set_reference_units:g.full_set_reference_tokens,full_set_reference_tokens:undefined,
   completed_subset_only:publicMetric(g.completed_subset_only)});
 }
 return {status:scored.status,punctuation_accuracy:'N/A',groups,cases};
}
function publicControls(score,side) {
 const cases=score.cases.map(c=>{const s=c[side];return {id:c.id,split:c.split,validation_role:'repeated_development',language:c.language,status:s.status,
  pcm_sha256:c.pcm_sha256,reference_sha256:c.reference_sha256,actual_text_sha256:s.text_sha256??null,primary:publicMetric(s.score),
  secondary:s.secondary_metrics??null,false_positive:s.false_positive??null,private_previously_seen:c.private_previously_seen,truncated:null};});
 const groups=score.speech_summaries.map(g=>({split:g.split,language:g.language,validation_role:'repeated_development',metric:g.metric,
  status:g.status,expected_cases:g.expected_cases,...g[side],full_set_reference_units:g[side].full_set_reference_tokens,full_set_reference_tokens:undefined,
  observed_success_subset:publicMetric(g[side].observed_success_subset),speaker_mean_rate:null}));
 return {cases,groups,negative_controls:{expected_cases:2,false_positives:score.negative_controls[side+'_false_positives'],cer_wer:null}};
}
export function privacyCheck(value){
 const forbidden=new Set(['text','reference','reference_raw','tokens','generated_ids','output_ids','pcm_path','audio_path','model_directory','stack']);
 if(Array.isArray(value))value.forEach(privacyCheck);
 else if(value&&typeof value==='object'){for(const [k,v]of Object.entries(value)){assert(!forbidden.has(k),`Private field: ${k}`);privacyCheck(v);}}
 else if(typeof value==='string')assert(!value.startsWith('/')&&!/\/(workspace|home|root)\//.test(value)&&!value.includes('\\'),'Absolute/private path');
}

async function main(){
 const args={};for(let i=2;i<process.argv.length;i+=2){assert(['--summary','--protocol','--input','--runner-exit-code','--output'].includes(process.argv[i]));assert(process.argv[i+1]);args[process.argv[i]]=process.argv[i+1];}
 for(const key of ['--summary','--protocol','--runner-exit-code','--output'])assert(args[key],`Required ${key}`);
 const summaryPath=path.resolve(args['--summary']),protocolPath=path.resolve(args['--protocol']),inputPath=path.resolve(args['--input']??PRIOR+'/data/all-inference.json');
 const {bundle,validation}=await loadVerifiedSuite(summaryPath,protocolPath,inputPath,Number(args['--runner-exit-code']));
 await scoreVerifiedSuite({bundle,validation,summaryPath,protocolPath,outputPath:path.resolve(args['--output'])});
}
export async function scoreVerifiedSuite({bundle,validation,summaryPath,protocolPath,outputPath}) {
 const sourceManifestPath=fileURLToPath(new URL('./SOURCE_MANIFEST.json',import.meta.url));
 const sourceManifest=await jsonFile(sourceManifestPath);
 for(const item of sourceManifest.value.files){assert(!path.isAbsolute(item.path)&&!item.path.split('/').includes('..'));assert.equal(sha(await fs.readFile(path.join(path.dirname(sourceManifestPath),item.path))),item.sha256,'Frozen scoring package source changed');}
 // Only after final-result verification may the scoring-only references be read.
 for(const [filename,expected]of pins)assert.equal(sha(await fs.readFile(filename)),expected,'Scoring source changed; review normalization');
 const names=['meli-all-inference.json','meli-all-scorer.local.json','controls-inference.json','controls-scorer.local.json','baseline-all-results.json','controls-baseline-results.local.json','qwen-accuracy-results-final.json'];
 const loaded=Object.fromEntries(await Promise.all(names.map(async n=>[n,await jsonFile(PRIOR+'/data/'+n)])));
 const native=await jsonFile(PRIOR+'/native-06-all.json');const previous=loaded['qwen-accuracy-results-final.json'].value;
 const previousBase=previous.schemes.find(s=>s.id==='default_browser_pipeline'),previousNative=previous.schemes.find(s=>s.id==='native_qwen06_int8');
 assert.equal(native.sha256,previousNative.provenance.raw_inference.sha256);
 assert.equal(loaded['baseline-all-results.json'].sha256,previousBase.provenance.meli_assembled.sha256);
 assert.equal(loaded['controls-baseline-results.local.json'].sha256,previousBase.provenance.controls_assembled.sha256);
 const oldMeli=loaded['meli-all-inference.json'].value,mi=repeatedMeliInput(oldMeli),mr=repeatedMeliReferences(loaded['meli-all-scorer.local.json'].value);
 const ci=loaded['controls-inference.json'].value,cr=loaded['controls-scorer.local.json'].value,base=loaded['baseline-all-results.json'].value,cb=loaded['controls-baseline-results.local.json'].value;
 const meliIds=new Set(mi.cases.map(c=>c.id));assert.equal(meliIds.size,23);assert.equal(oldMeli.cases.filter(c=>c.split==='holdout').length,8);
 const synthetic={status:validation.successful?'complete':'failed',worker_returncode:validation.parent_exit_code,cases:validation.validated.map(v=>({
  id:v.id,pcm_sha256:bundle.input.cases.find(c=>c.id===v.id).pcm_sha256,language:bundle.input.cases.find(c=>c.id===v.id).language,
  status:v.status,text:v.status==='complete'?v.engine.text:undefined,...(v.status==='complete'?{}:{error:{category:'worker_or_runner_evidence_failed'}})}))};
 const candidateMeli=scoreRun(mi,mr,{...synthetic,cases:sourceRows(synthetic,meliIds)},{format:'native',runnerExitCode:validation.parent_exit_code});
 const baselineMeli=scoreRun(mi,mr,{...base,cases:sourceRows(base,meliIds)},{format:'assembled'});
 const nativeMeli=scoreRun(mi,mr,{...native.value,cases:sourceRows(native.value,meliIds)},{format:'native',runnerExitCode:0});
 const candidateControls=scoreControls(ci,cr,synthetic,cb,{runnerExitCode:validation.parent_exit_code});
 const nativeControls=scoreControls(ci,cr,native.value,cb,{runnerExitCode:0});
 for(const [scored,old]of [[baselineMeli,previousBase],[nativeMeli,previousNative]])for(const c of scored.cases){const prior=old.meli.cases.find(r=>r.id===c.id);assert.equal(sha(c.text),prior.actual_text_sha256);assertScoreEqual(c.score,prior.primary);}
 for(const c of nativeControls.cases)for(const [side,old]of [['baseline',previousBase],['candidate',previousNative]]){const prior=old.controls.cases.find(r=>r.id===c.id);assert.equal(c[side].text_sha256,prior.actual_text_sha256);assertScoreEqual(c[side].score,prior.primary);assert.equal(c[side].secondary_metrics?.digit_equivalent_cer,prior.secondary?.digit_equivalent_cer);}
 const candidateId=validation.scheme_id??'web_wasm_worker_per_file';
 const schemes=[
  {id:'existing_default',source_inference:'Previously captured baseline, no new inference',meli:publicMeli(baselineMeli,oldMeli,true),controls:publicControls(nativeControls,'baseline')},
  {id:'existing_native_qwen06',source_inference:'Previously captured native CPU INT8, not Web WASM',meli:publicMeli(nativeMeli,oldMeli,true),controls:publicControls(nativeControls,'candidate')},
  {id:candidateId,source_inference:'This separately verified all31 lifecycle run only',meli:publicMeli(candidateMeli,oldMeli,validation.successful),controls:publicControls(candidateControls,'candidate')},
 ];
 const comparisons=[];for(const other of schemes.slice(0,2))for(const domain of ['meli','controls']){
  const by=new Map(other[domain].cases.map(c=>[c.id,c]));
  comparisons.push({baseline:other.id,candidate:candidateId,domain,cases:schemes[2][domain].cases.map(c=>{
   const b=by.get(c.id),delta=c.status==='complete'?(c.primary?c.primary.errors-b.primary.errors:Number(c.false_positive)-Number(b.false_positive)):null;
   return {id:c.id,current_split:'development',error_or_false_positive_delta:delta,outcome:delta==null?'unavailable':delta<0?'improved':delta>0?'regressed':'tied'};
  })});
 }
 const output={schema_version:1,status:validation.successful?'complete':'incomplete',scope:'Derived repeated-development lifecycle verification. No new holdout samples.',
  independent_new_holdout_cases:0,previous_round_holdout_cases_now_development:8,expected_cases:31,completed_cases:validation.completed_cases,
  protocol:{name:path.basename(protocolPath),sha256:bundle.protocolSha,id:bundle.protocol.protocol_id},
  provenance:{summary_name:path.basename(summaryPath),summary_sha256:bundle.summarySha,input_manifest_sha256:bundle.inputSha,
   script_sha256:sha(await fs.readFile(fileURLToPath(import.meta.url))),source_manifest_sha256:sourceManifest.sha256,scoring_sources:pins.map(([name,hash])=>({name:path.basename(name),sha256:hash})),
   previous_public_summary_sha256:loaded['qwen-accuracy-results-final.json'].sha256,native_source_sha256:native.sha256,
   baseline_meli_source_sha256:loaded['baseline-all-results.json'].sha256,baseline_controls_source_sha256:loaded['controls-baseline-results.local.json'].sha256},
  completion:{observed_parent_exit_code:validation.parent_exit_code,suite:'all31',diagnostic3_outputs_used:0,expected_cases:31,
   complete_cases:validation.completed_cases,uncompleted_cases:31-validation.completed_cases,full_accuracy_available:validation.successful,truncated_cases:null,
   worker_unit:validation.worker_unit??'file',expected_workers:validation.expected_workers??31,confirmed_worker_exits:validation.confirmed_worker_exits??validation.validated.filter(v=>v.exit_confirmed).length},
  runtime:validation.actual_runtime,settings:bundle.summary.settings,resource_semantics:bundle.summary.resource_semantics,
  cases:validation.validated.map(v=>({id:v.id,status:v.status,problems:v.problems,report_sha256:v.report_sha256,input_sha256:v.input_sha256,
   lifecycle_sha256:v.lifecycle_sha256,actual_text_sha256:typeof v.engine?.text==='string'?sha(v.engine.text):null,thread_id:v.thread_id,
   runner_exit_code:v.runner_exit_code,worker_exit_code:v.worker_exit_code,terminate_promise_exit_code:v.terminate_promise_exit_code,
   exit_confirmed:v.exit_confirmed,resource_after_worker_exit:v.resource_after_worker_exit,
   memory_after_decode:v.engine?.memory_after_decode??null,decode_seconds:v.engine?.decode_seconds??null,
   returned_token_count:Array.isArray(v.engine?.result?.tokens)?v.engine.result.tokens.length:null,truncated:null,
   input_coverage:v.coverage,expected_segments:v.expected_segments,complete_segments:v.complete_segments,segments:v.segment_public})),
  schemes,comparisons,limitations:[
   'All 31 recordings have been used before; the former eight holdout speakers are repeated development validation in this round.',
   'Only this all31 directory is scored. diagnostic3 results are never stitched in or selected as better alternatives.',
   'If this protocol segments recordings, every original sample is covered exactly once and complete-file text is only exact segment strings joined with one ASCII space. Segmentation can change accuracy and is evaluated as a distinct Web scheme.',
   'Runner exit zero and explicitly confirmed Worker termination are separate facts. terminate() may yield Worker exit one after a successful finalized runner.',
   'Exact Sherpa engine-returned text includes built-in processing and low-diversity tail protection; true generation truncation remains unknown.',
   'Actual Web WASM runs in browser-shaped Node VM inside worker_threads. It is not browser/mobile/codec/download-delivery QA. Parent and Workers share one OS process.',
   'Native and Web use different runtime builds, thread counts and context allocations; differences are not isolated quantization or platform effects.',
   'MELI punctuation accuracy is N/A. Chinese CER and English WER are separate. Strict CER counts digit-style and Traditional/Simplified writing differences; digit-equivalent CER is secondary only.',
   'Default silence/noise controls include VAD; direct Qwen does not. Negative-control differences compare systems.',
   'Failed or missing cases do not yield full-set accuracy. Successful-subset diagnostics are explicitly separate.',
  ]};
 privacyCheck(output);await fs.writeFile(outputPath,JSON.stringify(output,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({output:outputPath,status:output.status,completed_cases:output.completed_cases,expected_cases:31,sha256:sha(await fs.readFile(outputPath))}));
 return output;
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url)main().catch(error=>{console.error('Lifecycle scoring refused:',error.message);process.exitCode=1;});
