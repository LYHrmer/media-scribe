// Both mixture and vocals use the same production phase-safe downmix and FFmpeg
// resampler. No transcript, ASR output, or reference is read here.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { downmixChannels } from '/workspace/sites/tingxie-web/src/audio.js';
const root = path.dirname(fileURLToPath(import.meta.url));
const protocol = JSON.parse(await fs.readFile(path.join(root, 'protocol-frozen.json'), 'utf8'));
const sha = b => createHash('sha256').update(b).digest('hex');
assert.equal(sha(await fs.readFile('/workspace/sites/tingxie-web/src/audio.js')), protocol.production_audio_js_sha256);
const rows = [];
for (const [id, filename] of [['lyrics-mixture', 'input-stereo-44100.f32'], ['lyrics-vocals', 'vocals-stereo-44100.f32']]) {
  const input = await fs.readFile(path.join(root, filename));
  const samples = new Float32Array(input.buffer.slice(input.byteOffset, input.byteOffset + input.byteLength));
  assert.equal(samples.length % 2, 0);
  const left = new Float32Array(samples.length / 2), right = new Float32Array(samples.length / 2);
  for (let i = 0; i < left.length; ++i) { left[i] = samples[i * 2]; right[i] = samples[i * 2 + 1]; }
  const mono = downmixChannels([left, right]);
  const monoPath = path.join(root, `${id}-mono-44100.f32`);
  await fs.writeFile(monoPath, new Uint8Array(mono.buffer));
  const outputPath = path.join(root, `${id}-16000.f32`);
  execFileSync('ffmpeg', ['-v', 'error', '-y', '-f', 'f32le', '-ar', '44100', '-ac', '1', '-i', monoPath,
    '-ar', '16000', '-ac', '1', '-f', 'f32le', outputPath]);
  const output = await fs.readFile(outputPath);
  rows.push({ id, language: 'zh', pcm_path: outputPath, pcm_sha256: sha(output), sample_rate: 16000,
    audio_seconds: output.length / 4 / 16000, split: 'development-private-lyrics-vocals-pair' });
}
const anchor = protocol.frozen_baseline_pcm;
const original = await fs.readFile(anchor.path);
assert.equal(sha(original), anchor.sha256);
rows.unshift({ id: 'lyrics-frozen-original', language: 'zh', pcm_path: anchor.path, pcm_sha256: anchor.sha256,
  sample_rate: 16000, audio_seconds: original.length / 4 / 16000, split: 'development-private-lyrics-existing-baseline-reproduction' });
await fs.writeFile(path.join(root, 'comparison-inference.json'), JSON.stringify({ cases: rows }, null, 2) + '\n');
console.log(JSON.stringify({ prepared_cases: rows.length, references_read: false }));
