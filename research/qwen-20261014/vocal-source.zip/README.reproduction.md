# Frozen vocal-separation experiment

Status at preparation: the model and dependencies were downloaded and hash-checked;
the Python modules imported successfully. **No separation or candidate ASR inference
had been executed. No accuracy improvement has been demonstrated.** Execution
results, if subsequently recorded, must be reported separately from this protocol.

This is an offline CPU research comparison for one previously seen private lyric
video. It is not a browser feature, a new held-out test, or a downloadable product.
The archive intentionally contains no video, audio, model weights, third-party
source trees, reference lyrics, recognizer outputs, credentials, or package cache.

## Comparison fixed before inference

The single HTDemucs checkpoint `955717e8` uses CPU float32 inference, two PyTorch
threads, one interop thread, 7.8-second windows, 25% overlap, shifts=0, and no
parallel separation jobs. Standard Demucs input mean/std normalization is inverted
after separation. No extra EQ, gain, speed change, trimming, or clipping is applied.

All three outputs go through the same frozen recognizer configuration, separately
for production SenseVoice and native Sherpa Qwen3-ASR 0.6B INT8:

1. Existing frozen 16 kHz original PCM: reproduction anchor for the previous run.
2. Original stereo mixture: production phase-safe downmix, then FFmpeg 16 kHz resampling.
3. Separated vocals: the identical downmix and resampling path.

The primary separation contrast is **case 2 versus case 3 within the same ASR**.
Case 1 checks whether the previous baseline is reproducible. Do not compare only
the best result from different recognizers, remove failed runs, or use reference
lyrics to tune decoding. The strict seven-field inference manifest contains no
reference text. Scoring belongs in a separate process after inference and must
report both improvements and regressions. This single known video cannot establish
general singing accuracy or justify automatic product adoption.

## Sources and limitations

The Demucs implementation is pinned to official commit
`e976d93ecc3865e5757426930257e200846a520a`. Its Python algorithm files and the
Open-Unmix `filtering.py` are unmodified. The runner explicitly bootstraps the
Open-Unmix package to avoid its unused audio-IO initialization, which otherwise
requires an incompatible torchaudio release. Actual filtering code still executes
unchanged. FFmpeg performs media decoding and resampling; no cloud service receives
the input.

Demucs code is MIT. Its author separately states that the pretrained weights are
not covered by MIT and are provided for scientific purposes only. The weights are
not included here and are not approved as distributable product assets. See
`SOURCES.md` and `asset-provenance.json`.

The prepared environment has Python 3.12.14, torch 2.14.1+cpu, numpy 2.5.4,
scipy 1.18.1, soundfile 0.14.0, Node.js, and FFmpeg. The historical Python runtime
already existed; this archive does not guarantee that its precise torch build is
available from every public package index. Different framework/build versions are
a new environment and must be recorded as such, even when inference succeeds.

CPU time and peak RAM remain unmeasured at preparation. A four-GiB process-memory
estimate is a scheduling estimate, not a browser capability claim. Run separation
and both recognizers sequentially, with no other model/OCR job running.

## Reproduction in the recorded workspace

The frozen protocol and scripts retain the original absolute workspace paths and
file hashes, including private-media path metadata. **Those paths do not carry
the media.** Reproducing this exact private test requires separately authorized
access to the original file. A public user can run a new experiment on their own
media, but must create a new protocol and cannot label it the same frozen test.

1. Extract these small research files into
   `/workspace/experiments/lyrics-recovery-oct14/vocals`.
2. Use the existing CPU Python runtime at
   `/workspace/experiments/next-accuracy-oct14/official-venv/bin/python`, or record
   an explicitly different environment. Install the packages in
   `requirements-minimal.lock` into a **separate `vendor` directory** with
   `python -m pip install --no-deps --target vendor -r requirements-minimal.lock`.
   The parent environment must already provide torch, numpy, PyYAML, tqdm,
   cloudpickle, packaging, and normal Python dependencies. Do not let this command
   replace the existing ASR environment's torch installation.
3. Download the official source archive and checkpoint using the exact URLs in
   `asset-provenance.json`. Verify their full SHA-256 values before extracting the
   source or loading the checkpoint. Extract the source under the directory name
   `demucs-e976d93ecc3865e5757426930257e200846a520a`. Do not copy weights into a site
   or public repository.
4. Provide the authorized private media and the previous frozen PCM at the paths
   recorded in `protocol-frozen.json`. Decode stream `0:a:0` with FFmpeg as stereo
   float32 little-endian PCM at 44,100 Hz to `input-stereo-44100.f32`. Do not trim
   the clip. The frozen protocol validates its byte count and hash.
5. The project source must be at `/workspace/sites/tingxie-web`; its `src/audio.js`
   is hash-checked and imported for both comparison branches. The compiled v0.5.3
   production assets and the previously documented native Qwen runtime are needed
   for the ASR commands. Their existing benchmark runners are referenced, not
   duplicated in this archive.
6. Run `python run-htdemucs-vocals.py --verify-only`. This checks 304 recorded files
   and imports modules; it does not load a checkpoint or perform inference.
7. Execute the three operations from `commands.json` **in sequence**. The first
   command has a 600-second external timeout. A timeout/kill may leave the report
   at its last stage and must be reported as incomplete, never as a success.

The separator writes `separation-result.local.json`, private float32 PCM, and
`comparison-inference.json`. The two ASR runners write private recognizer outputs.
None of those generated media/transcript files belongs in a public source archive.
Publish only aggregate error counts, input/output hashes, timings, completion
status, configuration, and honest limitations.

`protocol-frozen.json` SHA-256:
`851856b8d3b9e79070422da9c38a2aa697a5fdc7f6cfeecc55aefd846cac7fe6`.
Do not edit the frozen file to make a failed hash check pass. Investigate missing
or different artifacts and preserve the original protocol.
