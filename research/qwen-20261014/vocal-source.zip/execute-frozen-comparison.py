#!/usr/bin/env python3
"""Execute frozen commands sequentially; this supervisor never reads references."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def events():
    return {k: int(v) for k, v in (line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}


def save(value):
    temp = ROOT / 'execution-receipt.local.json.tmp'
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(ROOT / 'execution-receipt.local.json')


def main():
    commands = json.loads((ROOT / 'commands.json').read_text())
    assert sha(ROOT / 'protocol-frozen.json') == '851856b8d3b9e79070422da9c38a2aa697a5fdc7f6cfeecc55aefd846cac7fe6'
    dist = Path('/workspace/sites/tingxie-web/dist')
    compiled = sorted(p for p in (dist / 'assets').glob('*.js') if p.name.startswith(('sensevoice.worker-', 'vad.worker-', 'punctuation.worker-')))
    receipt = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'protocol_sha256': sha(ROOT / 'protocol-frozen.json'),
               'commands_sha256': sha(ROOT / 'commands.json'),
               'scope': 'Exclusive serial CPU experiment; actual production dist v0.5.4 supplied by root; unchanged ASR weights/settings.',
               'compiled': [{'path': str(p), 'sha256': sha(p)} for p in compiled],
               'reference_access': False, 'memory_events_before': events(), 'runs': []}
    save(receipt)
    for name in ['run_separation', 'run_sensevoice', 'run_qwen_native']:
        item = commands[name]
        argv = item['argv'] if isinstance(item, dict) else item
        environment = os.environ.copy()
        if isinstance(item, dict):
            environment.update(item['env'])
        log_file = ROOT / (name + '.log.local.txt')
        before = events()
        start = time.monotonic()
        with log_file.open('wb') as log:
            process = subprocess.Popen(argv, stdout=log, stderr=subprocess.STDOUT, env=environment)
            _, status, usage = os.wait4(process.pid, 0)
            process.returncode = os.waitstatus_to_exitcode(status)
        row = {'stage': name, 'argv': argv, 'returncode': process.returncode,
               'wall_seconds': time.monotonic() - start, 'memory_events_before': before,
               'memory_events_after': events(), 'private_log_sha256': sha(log_file),
               'peak_rss_kib': usage.ru_maxrss, 'cpu_user_seconds': usage.ru_utime,
               'cpu_system_seconds': usage.ru_stime, 'resource_source': 'Linux wait4 child rusage'}
        receipt['runs'].append(row)
        save(receipt)
        print(json.dumps({k: row[k] for k in ['stage', 'returncode', 'wall_seconds', 'peak_rss_kib']}), flush=True)
        if name == 'run_separation' and process.returncode != 0:
            break
    receipt['memory_events_after'] = events()
    receipt['status'] = ('completed' if len(receipt['runs']) == 3 and all(r['returncode'] == 0 for r in receipt['runs']) else 'incomplete_or_failed')
    receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(receipt)


if __name__ == '__main__':
    main()
