#!/usr/bin/env python3
"""Frozen, offline source-separation research. Never reads a transcript.

The official Demucs algorithm and Open-Unmix filtering.py remain byte-identical.
An explicit package bootstrap avoids importing unused Open-Unmix audio I/O (and
its incompatible torchaudio dependency). It does not replace any math function.
Only the known, hash-verified official checkpoint is unpickled.
"""
import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import types

ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / 'protocol-frozen.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    tmp = Path(str(path) + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)


def imports(protocol):
    sys.path[:0] = [str(ROOT / protocol['source_directory']), str(ROOT / 'vendor')]
    # Run the genuine filtering module, without Open-Unmix's unused package API.
    package_path = ROOT / 'vendor' / 'openunmix'
    package = types.ModuleType('openunmix')
    package.__path__ = [str(package_path)]
    package.__package__ = 'openunmix'
    package.__spec__ = importlib.machinery.ModuleSpec('openunmix', loader=None, is_package=True)
    package.__spec__.submodule_search_locations = package.__path__
    sys.modules['openunmix'] = package
    import torch
    from demucs.apply import apply_model
    from demucs.states import load_model
    import openunmix.filtering
    assert sha(openunmix.filtering.__file__) == protocol['openunmix_filtering_sha256']
    return torch, apply_model, load_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    protocol = json.loads(PROTOCOL.read_text())
    for artifact in protocol['artifacts']:
        file = Path(artifact['path'])
        if not file.is_absolute():
            file = ROOT / file
        assert file.stat().st_size == artifact['bytes'], str(file)
        assert sha(file) == artifact['sha256'], str(file)
    torch, apply_model, load_model = imports(protocol)
    if args.verify_only:
        print(json.dumps({'verified': True, 'torch': torch.__version__, 'model_loaded': False,
                          'inference_performed': False, 'protocol_sha256': sha(PROTOCOL)}))
        return
    import numpy as np
    os.environ['OMP_NUM_THREADS'] = '2'
    os.environ['MKL_NUM_THREADS'] = '2'
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.manual_seed(42)
    np.random.seed(42)
    report = {'protocol_sha256': sha(PROTOCOL), 'status': 'loading',
              'torch_version': torch.__version__, 'network_requests': 0,
              'scope': 'CPU offline research; not a browser or mobile implementation',
              'reference_access': False}
    output = ROOT / 'separation-result.local.json'
    start = time.monotonic()
    write_json(output, report)
    try:
        # Checkpoint uses serialized class metadata, verified above from official source.
        package = torch.load(ROOT / protocol['checkpoint'], map_location='cpu', weights_only=False)
        model = load_model(package, strict=True).eval().to('cpu')
        assert model.samplerate == 44100 and model.audio_channels == 2
        assert model.sources == ['drums', 'bass', 'other', 'vocals']
        signal = np.fromfile(ROOT / protocol['input_pcm'], dtype='<f4').reshape(-1, 2)
        assert np.isfinite(signal).all()
        wav = torch.from_numpy(signal.T.copy())
        ref = wav.mean(0)
        mean, std = ref.mean(), ref.std() + 1e-8
        normalized = (wav - mean) / std
        report.update(status='separating', input_frames=len(signal),
                      parameter_count=sum(p.numel() for p in model.parameters()),
                      load_seconds=time.monotonic() - start)
        write_json(output, report)
        with torch.inference_mode():
            stems = apply_model(model, normalized[None], shifts=0, split=True,
                                overlap=0.25, transition_power=1.0, progress=False,
                                device='cpu', num_workers=0, segment=7.8)
        assert stems is not None
        vocals = stems[0, model.sources.index('vocals')] * std + mean
        assert vocals.shape == wav.shape and torch.isfinite(vocals).all()
        # Float32 PCM preserves amplitude; no automatic rescale, clipping, EQ, or trimming.
        vocals.T.contiguous().numpy().astype('<f4').tofile(ROOT / 'vocals-stereo-44100.f32')
        subprocess.run(['node', str(ROOT / 'prepare-comparison.mjs')], check=True)
        report.update(status='completed', elapsed_seconds=time.monotonic() - start,
                      peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      vocals_peak=float(vocals.abs().max()),
                      output_sha256=sha(ROOT / 'vocals-stereo-44100.f32'),
                      inference_manifest_sha256=sha(ROOT / 'comparison-inference.json'))
        write_json(output, report)
        print(json.dumps({k: report[k] for k in ['status', 'elapsed_seconds', 'peak_rss_kib', 'vocals_peak']}))
    except BaseException as error:
        report.update(status='failed', error_type=type(error).__name__, error=str(error),
                      elapsed_seconds=time.monotonic() - start,
                      peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        write_json(output, report)
        raise


if __name__ == '__main__':
    main()
