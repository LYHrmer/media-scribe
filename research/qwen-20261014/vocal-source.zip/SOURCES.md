# Official sources

- Demucs code commit:
  https://github.com/facebookresearch/demucs/tree/e976d93ecc3865e5757426930257e200846a520a
- Source archive:
  https://codeload.github.com/facebookresearch/demucs/tar.gz/e976d93ecc3865e5757426930257e200846a520a
- Official single-model selection (`htdemucs` maps to `955717e8`):
  https://github.com/facebookresearch/demucs/blob/e976d93ecc3865e5757426930257e200846a520a/demucs/remote/htdemucs.yaml
- Official checkpoint catalog:
  https://github.com/facebookresearch/demucs/blob/e976d93ecc3865e5757426930257e200846a520a/demucs/remote/files.txt
- Checkpoint (84,141,911 bytes):
  https://dl.fbaipublicfiles.com/demucs/hybrid_transformer/955717e8-8726e21a.th
- Demucs code license:
  https://github.com/facebookresearch/demucs/blob/e976d93ecc3865e5757426930257e200846a520a/LICENSE
- Distinct pretrained-weight restriction: official author Alexandre Defossez's
  May 23, 2022 reply at https://github.com/facebookresearch/demucs/issues/327
  states the weights are not covered by MIT and are provided for scientific
  purposes. This experiment does not redistribute them or treat them as product
  assets.
- Official source API normalization and inference:
  https://github.com/facebookresearch/demucs/blob/e976d93ecc3865e5757426930257e200846a520a/demucs/api.py
- Official Open-Unmix project (only its unchanged filtering module is executed):
  https://github.com/sigsep/open-unmix-pytorch

`asset-provenance.json` contains the downloaded archive and checkpoint hashes and
the public PyPI artifact URLs/hashes for the ten pinned Python dependency packages.
No executable third-party source or weight is bundled in this research archive.
