#!/usr/bin/env python3
"""Mechanical language enum adapter, preserving the failed first attempt.

Original manifest uses 'zh'; production SenseVoice accepts 'chinese'. Both denote
the same fixed language. PCM, model, timestamps setting, and candidate selection
remain unchanged. This script reads no result text or reference.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
original = root / 'comparison-inference.json'
adapted = root / 'sensevoice-language-adapter-inference.json'
manifest = json.loads(original.read_text())
assert len(manifest['cases']) == 3
for case in manifest['cases']:
    assert case['language'] == 'zh'
    case['language'] = 'chinese'
adapted.write_text(json.dumps(manifest, indent=2) + '\n')
commands = json.loads((root / 'commands.json').read_text())
command = commands['run_sensevoice']
argv = [str(adapted) if s == str(original) else s for s in command['argv']]
environment = dict(os.environ, **command['env'])
start = time.monotonic()
with (root / 'sensevoice-language-adapter.log.local.txt').open('wb') as log:
    process = subprocess.Popen(argv, env=environment, stdout=log, stderr=subprocess.STDOUT)
    _, status, usage = os.wait4(process.pid, 0)
    process.returncode = os.waitstatus_to_exitcode(status)
receipt = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'reason': 'First attempt rejected unsupported enum zh before ASR model loading; map it mechanically to chinese',
           'changes': {'language': ['zh', 'chinese']}, 'pcm_unchanged': True,
           'references_read': False, 'result_text_read_to_choose_retry': False,
           'original_manifest_sha256': sha(original), 'adapted_manifest_sha256': sha(adapted),
           'argv': argv, 'returncode': process.returncode,
           'wall_seconds': time.monotonic() - start, 'peak_rss_kib': usage.ru_maxrss,
           'cpu_user_seconds': usage.ru_utime, 'cpu_system_seconds': usage.ru_stime,
           'memory_events_after': Path('/sys/fs/cgroup/memory.events').read_text()}
(root / 'sensevoice-language-adapter-receipt.local.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['returncode', 'wall_seconds', 'peak_rss_kib']}))
raise SystemExit(process.returncode)
