# Executed vocal-separation comparison

The frozen offline HTDemucs comparison completed. **It did not solve the lyric
recognition problem. No separation feature or new weight was adopted in the app.**
This is one previously seen private development video, not independent evidence
of general singing or accent accuracy.

All scores use the existing strict Chinese lexical scorer: 22 reference characters,
NFKC normalization and punctuation/whitespace removal, without phonetic matching,
synonym substitution, or text repair. S/D/I use the existing deterministic
minimum-edit alignment. The scorer independently cross-checks its edit total with
the project's earlier scorer.

| Recognizer | Input | Errors / 22 | S | D | I |
| --- | --- | ---: | ---: | ---: | ---: |
| Production SenseVoice v0.5.4 compiled worker | Frozen original PCM | 20 / 22 | 5 | 15 | 0 |
| Production SenseVoice v0.5.4 compiled worker | Paired mixture control | 20 / 22 | 5 | 15 | 0 |
| Production SenseVoice v0.5.4 compiled worker | Separated vocals | 19 / 22 | 2 | 17 | 0 |
| Native Sherpa Qwen3-ASR 0.6B INT8 | Frozen original PCM | 20 / 22 | 16 | 4 | 0 |
| Native Sherpa Qwen3-ASR 0.6B INT8 | Paired mixture control | 19 / 22 | 16 | 3 | 0 |
| Native Sherpa Qwen3-ASR 0.6B INT8 | Separated vocals | 19 / 22 | 16 | 3 | 0 |

Within the proper paired control, SenseVoice has one fewer error but **more
deletions** (15 to 17). Qwen has no reduction in error count. Qwen's change from
20 errors on the old frozen PCM to 19 on vocals cannot be attributed to separation:
the paired resampling control already has 19. No recognizer was selected using
the reference answer. Both complete outputs were scored and retained privately.
Punctuation accuracy was not evaluated in this experiment.

| Serial stage | Exit code | Wall seconds | Peak RSS (KiB) |
| --- | ---: | ---: | ---: |
| Separation and comparison PCM preparation | 0 | 15.916 | 1,345,964 |
| First SenseVoice attempt, invalid language enum | 1 | 0.445 | 187,100 |
| Native Qwen, all three inputs | 0 | 16.717 | 2,757,272 |
| SenseVoice after mechanical language enum adapter, all three inputs | 0 | 18.326 | 1,749,892 |

The first SenseVoice attempt rejected `zh` before ASR model loading because the
production interface requires `chinese`. The original manifest, commands, protocol,
and failure receipt remain unchanged. A separate adapter maps only that enum;
PCM hashes, language meaning, model, and decoding settings remain unchanged. It
does not inspect reference text or candidate output to choose a retry. Execution
remained serial. All scoring occurred after every model process exited.

The initial monitoring supervisor also found `/usr/bin/time` unavailable before
launching any model. It was replaced by Linux `wait4` child-resource accounting;
the model commands were unchanged. The stage timings include startup and I/O.
The memory cgroup's `oom` and `oom_kill` counters stayed at 1 (preexisting events);
its `max` counter increased from 127348 to 132430. These CPU measurements do not
establish browser or phone memory feasibility.

Actual compiled SenseVoice worker:
`sensevoice.worker-gduX_vXW.js`, SHA-256
`0a4c728cd09265a5a48e6569f6ad4cb57e6a3bb1e975ac351050199fb22f4532`.
The supplied v0.5.4 build changes asset caching; ASR weights and configured decoding
remain the same. Full worker/runtime hashes, all S/D/I counts, recorded failures,
and output hashes are in `comparison-scores.public.json`. No private reference,
recognizer transcript, video, audio, or model weight is included.

`README.reproduction.md` documents the original preparation state; this file and
the numeric report document the subsequent execution. The frozen protocol SHA
remains `851856b8d3b9e79070422da9c38a2aa697a5fdc7f6cfeecc55aefd846cac7fe6`.
