// Post-inference only. Reads the private reference exclusively after all runs end.
// Never imports a model or changes text; publish hashes and S/D/I, not transcripts.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { lexicalScore, charTokens } from '/workspace/experiments/next-accuracy-oct14/scripts/score-next-accuracy.mjs';
const root = path.dirname(fileURLToPath(import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = async name => JSON.parse(await fs.readFile(path.join(root, name), 'utf8'));
const execution = await read('execution-receipt.local.json');
assert.equal(execution.runs.find(r => r.stage === 'run_separation').returncode, 0);
assert.equal(execution.runs.find(r => r.stage === 'run_qwen_native').returncode, 0);
const adapter = await read('sensevoice-language-adapter-receipt.local.json');
assert.equal(adapter.returncode, 0);
const manifest = await read('comparison-inference.json');
const native = await read('qwen-comparison.local.json');
const sense = await read('sensevoice-comparison.local.json');
assert.equal(native.status, 'complete');
assert.deepEqual(native.cases.map(c => c.id), manifest.cases.map(c => c.id));
assert.deepEqual(sense.cases.map(c => c.id), manifest.cases.map(c => c.id));
// Reference access is deliberately below completed-inference checks.
const scorerPath = '/workspace/experiments/next-accuracy-oct14/data/controls-scorer.local.json';
const scorer = JSON.parse(await fs.readFile(scorerPath, 'utf8'));
const gold = scorer.cases.find(c => c.id === 'user-lyrics');
assert(gold && typeof gold.reference === 'string');
assert.equal(charTokens(gold.reference).length, 22);
assert.equal(manifest.cases[0].pcm_sha256, gold.pcm_sha256);
const rows = [];
for (const [model, source] of [['production-sensevoice-v054', sense], ['native-qwen-06-int8', native]]) {
  for (const input of manifest.cases) {
    const row = source.cases.find(c => c.id === input.id);
    assert.equal(row.pcm_sha256, input.pcm_sha256);
    assert(!row.error);
    const text = model.startsWith('production-') ? row.result.text : row.text;
    assert.equal(typeof text, 'string');
    rows.push({ model, id: input.id, pcm_sha256: input.pcm_sha256,
      text_sha256: sha(text), score: lexicalScore(gold.reference, text, 'chinese'),
      seconds: row.seconds ?? row.elapsed_seconds ?? null });
  }
}
const comparisons = ['production-sensevoice-v054', 'native-qwen-06-int8'].map(model => {
  const base = rows.find(r => r.model === model && r.id === 'lyrics-mixture');
  const candidate = rows.find(r => r.model === model && r.id === 'lyrics-vocals');
  return { model, primary_contrast: 'same-model resampling-control mixture versus separated vocals',
    mixture_errors: base.score.errors, vocal_errors: candidate.score.errors,
    error_delta: candidate.score.errors - base.score.errors };
});
const report = { schema_version: 1, status: 'complete_after_enum_adapter',
  scope: 'One already-seen private lyric development sample; not held-out accuracy or browser validation',
  protocol_sha256: sha(await fs.readFile(path.join(root, 'protocol-frozen.json'))),
  reference_sha256: sha(gold.reference), reference_units: 22,
  punctuation: 'Not evaluated; lexical CER removes punctuation. No punctuation accuracy claim.',
  compiled: execution.compiled, actual_sensevoice_fingerprints: sense.fingerprints,
  execution: { initial_runs: execution.runs, sensevoice_compatibility_retry: adapter,
    memory_events_before: execution.memory_events_before,
    memory_events_after: adapter.memory_events_after },
  cases: rows, comparisons,
  source_hashes: Object.fromEntries(await Promise.all(['separation-result.local.json','qwen-comparison.local.json','sensevoice-comparison.local.json','execution-receipt.local.json','sensevoice-language-adapter-receipt.local.json'].map(async name => [name, sha(await fs.readFile(path.join(root, name)))]))),
  limitations: ['A single known song cannot establish generalization.', 'No product model was replaced.',
    'First SenseVoice attempt failed an enum check before loading ASR; all PCM/configurations were preserved in the documented mechanical adapter.',
    'Native Qwen and offline Demucs are not browser or mobile feasibility tests.'] };
await fs.writeFile(path.join(root, 'comparison-scores.public.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ cases: rows.map(r => ({ model: r.model, id: r.id,
  errors: r.score.errors, reference: r.score.reference_tokens, S: r.score.substitutions,
  D: r.score.deletions, I: r.score.insertions })), comparisons }, null, 2));
